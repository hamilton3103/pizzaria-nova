import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    exclude: ['lucide-react']
  },
  resolve: {
    alias: {
      // Polyfill Node.js specific modules for the browser
      buffer: 'buffer/',
      stream: 'stream-browserify',
      util: 'util/',
      crypto: 'crypto-browserify'
    }
  },
  define: {
    // Add Node.js global variables
    'process.env': {},
    'global': {}
  }
});