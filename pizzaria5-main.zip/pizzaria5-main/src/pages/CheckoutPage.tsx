import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, CreditCard, Smartphone, User, Check } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { dataService } from '../services/supabase';
import { toast } from 'react-hot-toast';

type PaymentMethod = 'pix' | 'credit_card' | 'cash';
type CheckoutStep = 'address' | 'payment' | 'confirmation';

const CheckoutPage: React.FC = () => {
  const { items, subtotal, deliveryFee, total, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('address');
  const [addresses, setAddresses] = useState<any[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<any>(null);
  const [newAddress, setNewAddress] = useState({
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
    zip_code: '',
    is_default: false,
  });
  
  const [showNewAddressForm, setShowNewAddressForm] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    // Redirect if cart is empty
    if (items.length === 0 && !orderPlaced) {
      navigate('/');
      return;
    }

    // Redirect if not authenticated
    if (!isAuthenticated) {
      navigate('/login?redirect=checkout');
      return;
    }
    
    // Load user addresses
    if (user) {
      loadAddresses();
    }
  }, [items, navigate, user, isAuthenticated, orderPlaced]);

  const loadAddresses = async () => {
    if (!user) return;

    try {
      const userAddresses = await dataService.getUserAddresses(user.id);
      setAddresses(userAddresses);
      
      if (userAddresses.length > 0) {
        const defaultAddress = userAddresses.find(addr => addr.is_default) || userAddresses[0];
        setSelectedAddress(defaultAddress);
      }
    } catch (error) {
      console.error('Error loading addresses:', error);
      toast.error('Erro ao carregar endereços');
    }
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };
  
  const handleAddressSelect = (address: any) => {
    setSelectedAddress(address);
    setShowNewAddressForm(false);
  };
  
  const handleNewAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setNewAddress({
      ...newAddress,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  const handleNewAddressSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      setLoading(true);
      const address = await dataService.addAddress({
        user_id: user.id,
        ...newAddress
      });
      
      setAddresses([...addresses, address]);
      setSelectedAddress(address);
      setShowNewAddressForm(false);
      setNewAddress({
        street: '',
        number: '',
        complement: '',
        neighborhood: '',
        city: '',
        state: '',
        zip_code: '',
        is_default: false,
      });
      toast.success('Endereço adicionado com sucesso');
    } catch (error) {
      console.error('Error adding address:', error);
      toast.error('Erro ao adicionar endereço');
    } finally {
      setLoading(false);
    }
  };
  
  const goToNextStep = () => {
    if (currentStep === 'address') {
      if (!selectedAddress) {
        toast.error('Selecione um endereço de entrega');
        return;
      }
      setCurrentStep('payment');
    } else if (currentStep === 'payment') {
      placeOrder();
    }
  };
  
  const goToPreviousStep = () => {
    if (currentStep === 'payment') {
      setCurrentStep('address');
    }
  };
  
  const placeOrder = async () => {
    if (!user || !selectedAddress) return;

    try {
      setLoading(true);

      const orderData = {
        user_id: user.id,
        address_id: selectedAddress.id,
        payment_method: paymentMethod,
        subtotal,
        delivery_fee: deliveryFee,
        total,
        items: items.map(item => ({
          product_id: item.product.id,
          quantity: item.quantity,
          unit_price: item.product.promo_price || item.product.price,
          notes: item.notes
        }))
      };

      const order = await dataService.createOrder(orderData);
      setOrderId(order.id);
      setOrderPlaced(true);
      setCurrentStep('confirmation');
      clearCart();
      toast.success('Pedido realizado com sucesso!');
    } catch (error) {
      console.error('Error placing order:', error);
      toast.error('Erro ao realizar pedido');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-neutral-100 min-h-screen py-8">
      <div className="container mx-auto px-4 md:px-0">
        <h1 className="text-3xl font-bold mb-8">Finalizar Pedido</h1>
        
        {/* Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            <div className={`flex flex-col items-center ${currentStep === 'address' ? 'text-primary' : 'text-neutral-600'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${currentStep === 'address' ? 'bg-primary text-white' : 'bg-neutral-200'}`}>
                <MapPin size={20} />
              </div>
              <span>Endereço</span>
            </div>
            
            <div className={`w-16 h-1 mx-2 ${currentStep === 'address' ? 'bg-neutral-200' : 'bg-primary'}`}></div>
            
            <div className={`flex flex-col items-center ${currentStep === 'payment' ? 'text-primary' : currentStep === 'confirmation' ? 'text-primary' : 'text-neutral-600'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${currentStep === 'payment' ? 'bg-primary text-white' : currentStep === 'confirmation' ? 'bg-primary text-white' : 'bg-neutral-200'}`}>
                <CreditCard size={20} />
              </div>
              <span>Pagamento</span>
            </div>
            
            <div className={`w-16 h-1 mx-2 ${currentStep === 'confirmation' ? 'bg-primary' : 'bg-neutral-200'}`}></div>
            
            <div className={`flex flex-col items-center ${currentStep === 'confirmation' ? 'text-primary' : 'text-neutral-600'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${currentStep === 'confirmation' ? 'bg-primary text-white' : 'bg-neutral-200'}`}>
                <Check size={20} />
              </div>
              <span>Confirmação</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              {/* Address Step */}
              {currentStep === 'address' && (
                <div>
                  <h2 className="text-xl font-bold mb-6">Endereço de Entrega</h2>
                  
                  {addresses.length > 0 && !showNewAddressForm && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-4">Endereços Salvos</h3>
                      <div className="space-y-4">
                        {addresses.map((address) => (
                          <div
                            key={address.id}
                            className={`border rounded-md p-4 cursor-pointer transition-colors ${
                              selectedAddress?.id === address.id
                                ? 'border-primary bg-primary/5'
                                : 'border-gray-200 hover:border-primary'
                            }`}
                            onClick={() => handleAddressSelect(address)}
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-medium">
                                  {address.street}, {address.number}
                                  {address.complement && ` - ${address.complement}`}
                                </p>
                                <p className="text-neutral-600">
                                  {address.neighborhood}, {address.city} - {address.state}
                                </p>
                                <p className="text-neutral-600">CEP: {address.zip_code}</p>
                              </div>
                              {address.is_default && (
                                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
                                  Padrão
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {showNewAddressForm ? (
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Novo Endereço</h3>
                      <form onSubmit={handleNewAddressSubmit}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="street" className="block text-sm font-medium text-neutral-700 mb-1">
                              Rua
                            </label>
                            <input
                              type="text"
                              id="street"
                              name="street"
                              value={newAddress.street}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="number" className="block text-sm font-medium text-neutral-700 mb-1">
                              Número
                            </label>
                            <input
                              type="text"
                              id="number"
                              name="number"
                              value={newAddress.number}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <label htmlFor="complement" className="block text-sm font-medium text-neutral-700 mb-1">
                            Complemento (opcional)
                          </label>
                          <input
                            type="text"
                            id="complement"
                            name="complement"
                            value={newAddress.complement}
                            onChange={handleNewAddressChange}
                            className="input"
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="neighborhood" className="block text-sm font-medium text-neutral-700 mb-1">
                              Bairro
                            </label>
                            <input
                              type="text"
                              id="neighborhood"
                              name="neighborhood"
                              value={newAddress.neighborhood}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="zip_code" className="block text-sm font-medium text-neutral-700 mb-1">
                              CEP
                            </label>
                            <input
                              type="text"
                              id="zip_code"
                              name="zip_code"
                              value={newAddress.zip_code}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="city" className="block text-sm font-medium text-neutral-700 mb-1">
                              Cidade
                            </label>
                            <input
                              type="text"
                              id="city"
                              name="city"
                              value={newAddress.city}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="state" className="block text-sm font-medium text-neutral-700 mb-1">
                              Estado
                            </label>
                            <input
                              type="text"
                              id="state"
                              name="state"
                              value={newAddress.state}
                              onChange={handleNewAddressChange}
                              required
                              className="input"
                            />
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              name="is_default"
                              checked={newAddress.is_default}
                              onChange={handleNewAddressChange}
                              className="mr-2"
                            />
                            <span className="text-sm text-neutral-700">Definir como endereço padrão</span>
                          </label>
                        </div>
                        
                        <div className="flex space-x-4">
                          <button
                            type="button"
                            onClick={() => setShowNewAddressForm(false)}
                            className="btn btn-outline"
                          >
                            Cancelar
                          </button>
                          <button 
                            type="submit" 
                            disabled={loading}
                            className="btn btn-primary"
                          >
                            {loading ? 'Salvando...' : 'Salvar Endereço'}
                          </button>
                        </div>
                      </form>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowNewAddressForm(true)}
                      className="btn btn-outline mb-6"
                    >
                      Adicionar Novo Endereço
                    </button>
                  )}
                  
                  <div className="mt-8">
                    <button
                      onClick={goToNextStep}
                      disabled={!selectedAddress}
                      className={`btn btn-primary w-full ${
                        !selectedAddress ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      Continuar para Pagamento
                    </button>
                  </div>
                </div>
              )}
              
              {/* Payment Step */}
              {currentStep === 'payment' && (
                <div>
                  <h2 className="text-xl font-bold mb-6">Método de Pagamento</h2>
                  
                  <div className="space-y-4 mb-8">
                    <label
                      className={`block border rounded-md p-4 cursor-pointer transition-colors ${
                        paymentMethod === 'pix'
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 hover:border-primary'
                      }`}
                    >
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="pix"
                        checked={paymentMethod === 'pix'}
                        onChange={() => setPaymentMethod('pix')}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <Smartphone size={24} className="text-primary mr-3" />
                        <div>
                          <p className="font-medium">PIX</p>
                          <p className="text-sm text-neutral-600">
                            Pagamento instantâneo
                          </p>
                        </div>
                      </div>
                    </label>
                    
                    <label
                      className={`block border rounded-md p-4 cursor-pointer transition-colors ${
                        paymentMethod === 'credit_card'
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 hover:border-primary'
                      }`}
                    >
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="credit_card"
                        checked={paymentMethod === 'credit_card'}
                        onChange={() => setPaymentMethod('credit_card')}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <CreditCard size={24} className="text-primary mr-3" />
                        <div>
                          <p className="font-medium">Cartão de Crédito/Débito</p>
                          <p className="text-sm text-neutral-600">
                            Visa, Mastercard, Elo, etc.
                          </p>
                        </div>
                      </div>
                    </label>
                    
                    <label
                      className={`block border rounded-md p-4 cursor-pointer transition-colors ${
                        paymentMethod === 'cash'
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 hover:border-primary'
                      }`}
                    >
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cash"
                        checked={paymentMethod === 'cash'}
                        onChange={() => setPaymentMethod('cash')}
                        className="sr-only"
                      />
                      <div className="flex items-center">
                        <User size={24} className="text-primary mr-3" />
                        <div>
                          <p className="font-medium">Dinheiro na Entrega</p>
                          <p className="text-sm text-neutral-600">
                            Pague diretamente ao entregador
                          </p>
                        </div>
                      </div>
                    </label>
                  </div>
                  
                  {paymentMethod === 'pix' && (
                    <div className="mb-8">
                      <h3 className="text-lg font-semibold mb-4">Informações do PIX</h3>
                      <div className="bg-neutral-100 p-4 rounded-md text-center">
                        <p className="mb-2">Chave PIX (Telefone):</p>
                        <p className="font-bold mb-4">14997383236</p>
                        <p className="text-sm text-neutral-600 mb-2">
                          1. Copie a chave PIX acima
                        </p>
                        <p className="text-sm text-neutral-600 mb-2">
                          2. Abra o aplicativo do seu banco
                        </p>
                        <p className="text-sm text-neutral-600 mb-2">
                          3. Realize a transferência para o valor de {formatPrice(total)}
                        </p>
                        <p className="text-sm text-neutral-600">
                          4. Finalize seu pedido
                        </p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex space-x-4 mt-8">
                    <button
                      onClick={goToPreviousStep}
                      className="btn btn-outline flex-1"
                    >
                      Voltar
                    </button>
                    <button
                      onClick={goToNextStep}
                      disabled={loading}
                      className="btn btn-primary flex-1"
                    >
                      {loading ? 'Processando...' : 'Finalizar Pedido'}
                    </button>
                  </div>
                </div>
              )}
              
              {/* Confirmation Step */}
              {currentStep === 'confirmation' && (
                <div className="text-center py-8">
                  <div className="flex justify-center mb-6">
                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                      <Check size={40} className="text-green-600" />
                    </div>
                  </div>
                  
                  <h2 className="text-2xl font-bold mb-2">Pedido Confirmado!</h2>
                  <p className="text-lg text-neutral-600 mb-4">
                    Seu pedido foi recebido e está sendo processado.
                  </p>
                  
                  <div className="max-w-md mx-auto bg-neutral-100 p-4 rounded-md mb-6">
                    <h3 className="font-semibold mb-2">Resumo do Pedido:</h3>
                    <p className="mb-1">
                      <span className="font-medium">Método de Pagamento:</span>{' '}
                      {paymentMethod === 'pix'
                        ? 'PIX'
                        : paymentMethod === 'credit_card'
                        ? 'Cartão de Crédito/Débito'
                        : 'Dinheiro na Entrega'}
                    </p>
                    <p className="mb-1">
                      <span className="font-medium">Endereço de Entrega:</span>{' '}
                      {selectedAddress &&
                        `${selectedAddress.street}, ${selectedAddress.number}, ${selectedAddress.neighborhood}, ${selectedAddress.city} - ${selectedAddress.state}`}
                    </p>
                    <p>
                      <span className="font-medium">Total:</span> {formatPrice(total)}
                    </p>
                  </div>
                  
                  <div className="flex justify-center">
                    <button
                      onClick={() => navigate('/')}
                      className="btn btn-primary"
                    >
                      Voltar para a Página Inicial
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Order Summary */}
          {(currentStep === 'address' || currentStep === 'payment') && (
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
                <h2 className="text-xl font-bold mb-6">Resumo do Pedido</h2>
                
                <div className="mb-6">
                  {items.map((item, index) => (
                    <div key={index} className="flex justify-between py-2 border-b border-gray-200 last:border-b-0">
                      <div>
                        <span className="font-medium">
                          {item.quantity}x {item.product.name}
                        </span>
                        {item.selectedOptions && item.selectedOptions.length > 0 && (
                          <p className="text-sm text-neutral-600">
                            {item.selectedOptions[0].name}
                          </p>
                        )}
                      </div>
                      <span>
                        {formatPrice(
                          ((item.product.promo_price || item.product.price) +
                            (item.selectedOptions?.[0]?.price || 0)) *
                            item.quantity
                        )}
                      </span>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de entrega</span>
                    <span>{formatPrice(deliveryFee)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4 flex justify-between font-bold">
                    <span>Total</span>
                    <span className="text-xl">{formatPrice(total)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;