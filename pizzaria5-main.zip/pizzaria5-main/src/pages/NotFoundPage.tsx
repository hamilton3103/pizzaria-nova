import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Pizza } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-neutral-100">
      <div className="text-center px-4">
        <div className="relative">
          <h1 className="text-9xl font-bold text-primary/10">404</h1>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <Pizza size={80} className="text-primary mb-4" />
            <h2 className="text-3xl font-bold text-neutral-800">Página não encontrada</h2>
            <p className="text-neutral-600 mt-2">
              Parece que você seguiu um link quebrado ou inseriu uma URL que não existe.
            </p>
          </div>
        </div>
        
        <div className="mt-12 space-x-4">
          <Link 
            to="/" 
            className="btn btn-primary inline-flex items-center"
          >
            <Home size={20} className="mr-2" />
            Voltar para o Início
          </Link>
          
          <Link 
            to="/menu/pizza" 
            className="btn btn-outline inline-flex items-center"
          >
            <Pizza size={20} className="mr-2" />
            Ver Cardápio
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;