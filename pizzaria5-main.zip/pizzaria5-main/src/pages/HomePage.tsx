import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import InstagramFeed from '../components/InstagramFeed';
import { useProducts } from '../hooks/useProducts';

const HomePage: React.FC = () => {
  const { products: promotions } = useProducts({ featured: true, active: true });
  const { products: popularProducts } = useProducts({ popular: true, active: true });
  const { products: pizzas } = useProducts({ category: 'pizzas', active: true });
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[60vh] bg-cover bg-center flex items-center" style={{ backgroundImage: 'url(https://images.pexels.com/photos/905847/pexels-photo-905847.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)' }}>
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <div className="container mx-auto relative z-10 px-4 md:px-0">
          <div className="max-w-xl">
            <h1 className="text-white text-4xl md:text-5xl font-bold mb-4 animate-slide-up">
              As melhores pizzas, lanches no baguete, hambúrgueres e salgados
            </h1>
            <p className="text-white text-xl mb-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              Sabor inigualável, qualidade superior. Peça agora!
            </p>
            <div className="flex space-x-4 animate-slide-up" style={{ animationDelay: '0.4s' }}>
              <Link to="/menu/promocoes" className="btn btn-secondary">
                Ver Promoções
              </Link>
              <Link to="/menu/pizzas" className="btn btn-outline border-white text-white hover:bg-white hover:text-neutral-900">
                Cardápio
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 md:px-0">
          <h2 className="text-3xl font-bold mb-8 text-center">Categorias</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Link
              to="/menu/promocoes"
              className="bg-accent/10 rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="h-16 w-16 mx-auto mb-4 bg-accent/20 rounded-full flex items-center justify-center">
                <span className="text-accent text-2xl font-bold">%</span>
              </div>
              <h3 className="text-lg font-semibold">Promoções</h3>
            </Link>
            
            <Link
              to="/menu/pizzas"
              className="bg-primary/10 rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="h-16 w-16 mx-auto mb-4 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-primary text-2xl font-bold">🍕</span>
              </div>
              <h3 className="text-lg font-semibold">Pizzas</h3>
            </Link>
            
            <Link
              to="/menu/lanches"
              className="bg-secondary/10 rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="h-16 w-16 mx-auto mb-4 bg-secondary/20 rounded-full flex items-center justify-center">
                <span className="text-secondary-dark text-2xl font-bold">🍔</span>
              </div>
              <h3 className="text-lg font-semibold">Lanches</h3>
            </Link>
            
            <Link
              to="/menu/bebidas"
              className="bg-blue-100 rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="h-16 w-16 mx-auto mb-4 bg-blue-200 rounded-full flex items-center justify-center">
                <span className="text-blue-600 text-2xl font-bold">🥤</span>
              </div>
              <h3 className="text-lg font-semibold">Bebidas</h3>
            </Link>
            
            <Link
              to="/menu/sobremesas"
              className="bg-pink-100 rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="h-16 w-16 mx-auto mb-4 bg-pink-200 rounded-full flex items-center justify-center">
                <span className="text-pink-600 text-2xl font-bold">🍰</span>
              </div>
              <h3 className="text-lg font-semibold">Sobremesas</h3>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Promotions */}
      {promotions.length > 0 && (
        <section className="py-12 bg-neutral-100">
          <div className="container mx-auto px-4 md:px-0">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold">Promoções</h2>
              <Link to="/menu/promocoes" className="text-primary font-medium flex items-center hover:underline">
                Ver todas
                <ChevronRight size={16} />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {promotions.slice(0, 3).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* Popular Products */}
      {popularProducts.length > 0 && (
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4 md:px-0">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold">Mais Vendidos</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {popularProducts.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* Featured */}
      <section className="py-12 bg-primary">
        <div className="container mx-auto px-4 md:px-0">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="text-3xl text-white font-bold mb-4">Pizza do Mês</h2>
              <p className="text-white text-lg mb-6">
                Experimente nossa incrível pizza de calabresa com borda recheada de catupiry. Feita com ingredientes selecionados para uma experiência única de sabor.
              </p>
              <Link to="/menu/pizzas" className="btn bg-white text-primary hover:bg-neutral-100">
                Ver Pizzas
              </Link>
            </div>
            <div className="md:w-1/2 md:pl-8">
              <img
                src="https://images.pexels.com/photos/4109111/pexels-photo-4109111.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Pizza do Mês"
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Pizzas */}
      {pizzas.length > 0 && (
        <section className="py-12 bg-neutral-100">
          <div className="container mx-auto px-4 md:px-0">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold">Nossas Pizzas</h2>
              <Link to="/menu/pizzas" className="text-primary font-medium flex items-center hover:underline">
                Ver todas
                <ChevronRight size={16} />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {pizzas.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}
      
      {/* Instagram Feed */}
      <InstagramFeed />
    </div>
  );
};

export default HomePage;