import React, { useState } from 'react';
import { Save, Bell, Shield, Globe, Truck, CreditCard, Mail, Database, Server } from 'lucide-react';
import { toast } from 'react-hot-toast';

const AdminSettings: React.FC = () => {
  const [settings, setSettings] = useState({
    // General Settings
    siteName: 'Laricas Pizzaria',
    siteDescription: 'As melhores pizzas da cidade',
    contactEmail: 'contato@laricas.com',
    contactPhone: '(14) 99738-3236',
    
    // Delivery Settings
    deliveryFee: 5.00,
    freeDeliveryMinimum: 50.00,
    deliveryRadius: 10,
    estimatedDeliveryTime: 45,
    
    // Payment Settings
    pixEnabled: true,
    creditCardEnabled: true,
    cashEnabled: true,
    
    // Notification Settings
    emailNotifications: true,
    smsNotifications: false,
    orderNotifications: true,
    promotionNotifications: true,
    
    // Database Settings
    dbHost: '192.185.176.242',
    dbUser: 'laricas_bdados',
    dbName: 'laricas_bdados',
    dbPort: 3306,
    
    // Business Hours
    businessHours: {
      monday: { open: '18:00', close: '23:00', closed: true },
      tuesday: { open: '18:00', close: '23:00', closed: false },
      wednesday: { open: '18:00', close: '23:00', closed: false },
      thursday: { open: '18:00', close: '23:00', closed: false },
      friday: { open: '18:00', close: '23:00', closed: false },
      saturday: { open: '18:00', close: '23:00', closed: false },
      sunday: { open: '18:00', close: '23:00', closed: false },
    }
  });

  const [activeTab, setActiveTab] = useState('general');

  const handleInputChange = (field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBusinessHoursChange = (day: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      businessHours: {
        ...prev.businessHours,
        [day]: {
          ...prev.businessHours[day],
          [field]: value
        }
      }
    }));
  };

  const handleSave = () => {
    // Mock save functionality
    toast.success('Configurações salvas com sucesso!');
  };

  const tabs = [
    { id: 'general', label: 'Geral', icon: Globe },
    { id: 'delivery', label: 'Entrega', icon: Truck },
    { id: 'payment', label: 'Pagamento', icon: CreditCard },
    { id: 'notifications', label: 'Notificações', icon: Bell },
    { id: 'database', label: 'Banco de Dados', icon: Database },
    { id: 'hours', label: 'Horários', icon: Shield },
  ];

  const dayNames = {
    monday: 'Segunda-feira',
    tuesday: 'Terça-feira',
    wednesday: 'Quarta-feira',
    thursday: 'Quinta-feira',
    friday: 'Sexta-feira',
    saturday: 'Sábado',
    sunday: 'Domingo',
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">Configurações</h1>
        <button 
          onClick={handleSave}
          className="btn btn-primary inline-flex items-center"
        >
          <Save size={20} className="mr-1" />
          Salvar Configurações
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <nav className="space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center px-4 py-3 text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon size={20} className="mr-3" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-md p-6">
            {/* General Settings */}
            {activeTab === 'general' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Configurações Gerais</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nome do Site
                    </label>
                    <input
                      type="text"
                      value={settings.siteName}
                      onChange={(e) => handleInputChange('siteName', e.target.value)}
                      className="input w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Descrição do Site
                    </label>
                    <textarea
                      value={settings.siteDescription}
                      onChange={(e) => handleInputChange('siteDescription', e.target.value)}
                      rows={3}
                      className="input w-full"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email de Contato
                      </label>
                      <input
                        type="email"
                        value={settings.contactEmail}
                        onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                        className="input w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Telefone de Contato
                      </label>
                      <input
                        type="tel"
                        value={settings.contactPhone}
                        onChange={(e) => handleInputChange('contactPhone', e.target.value)}
                        className="input w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Delivery Settings */}
            {activeTab === 'delivery' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Configurações de Entrega</h2>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Taxa de Entrega (R$)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={settings.deliveryFee}
                        onChange={(e) => handleInputChange('deliveryFee', parseFloat(e.target.value))}
                        className="input w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Entrega Grátis a partir de (R$)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={settings.freeDeliveryMinimum}
                        onChange={(e) => handleInputChange('freeDeliveryMinimum', parseFloat(e.target.value))}
                        className="input w-full"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Raio de Entrega (km)
                      </label>
                      <input
                        type="number"
                        value={settings.deliveryRadius}
                        onChange={(e) => handleInputChange('deliveryRadius', parseInt(e.target.value))}
                        className="input w-full"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Tempo Estimado de Entrega (min)
                      </label>
                      <input
                        type="number"
                        value={settings.estimatedDeliveryTime}
                        onChange={(e) => handleInputChange('estimatedDeliveryTime', parseInt(e.target.value))}
                        className="input w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Payment Settings */}
            {activeTab === 'payment' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Métodos de Pagamento</h2>
                <div className="space-y-6">
                  <div className="space-y-4">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.pixEnabled}
                        onChange={(e) => handleInputChange('pixEnabled', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">PIX</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.creditCardEnabled}
                        onChange={(e) => handleInputChange('creditCardEnabled', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Cartão de Crédito/Débito</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.cashEnabled}
                        onChange={(e) => handleInputChange('cashEnabled', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Dinheiro na Entrega</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Configurações de Notificação</h2>
                <div className="space-y-6">
                  <div className="space-y-4">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.emailNotifications}
                        onChange={(e) => handleInputChange('emailNotifications', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Notificações por Email</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.smsNotifications}
                        onChange={(e) => handleInputChange('smsNotifications', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Notificações por SMS</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.orderNotifications}
                        onChange={(e) => handleInputChange('orderNotifications', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Notificações de Pedidos</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={settings.promotionNotifications}
                        onChange={(e) => handleInputChange('promotionNotifications', e.target.checked)}
                        className="mr-3"
                      />
                      <span className="text-sm font-medium">Notificações de Promoções</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Database Settings */}
            {activeTab === 'database' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Configurações do Banco de Dados</h2>
                <div className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center">
                      <Server size={20} className="text-blue-600 mr-2" />
                      <span className="text-blue-800 font-medium">Status: Conectado</span>
                    </div>
                    <p className="text-blue-700 text-sm mt-1">
                      Conexão ativa com o banco de dados MySQL
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Host do Banco
                      </label>
                      <input
                        type="text"
                        value={settings.dbHost}
                        onChange={(e) => handleInputChange('dbHost', e.target.value)}
                        className="input w-full"
                        readOnly
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Porta
                      </label>
                      <input
                        type="number"
                        value={settings.dbPort}
                        onChange={(e) => handleInputChange('dbPort', parseInt(e.target.value))}
                        className="input w-full"
                        readOnly
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nome do Banco
                      </label>
                      <input
                        type="text"
                        value={settings.dbName}
                        onChange={(e) => handleInputChange('dbName', e.target.value)}
                        className="input w-full"
                        readOnly
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Usuário
                      </label>
                      <input
                        type="text"
                        value={settings.dbUser}
                        onChange={(e) => handleInputChange('dbUser', e.target.value)}
                        className="input w-full"
                        readOnly
                      />
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <p className="text-yellow-800 text-sm">
                      <strong>Nota:</strong> As configurações do banco de dados são somente leitura por segurança.
                      Para alterações, entre em contato com o administrador do sistema.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Business Hours */}
            {activeTab === 'hours' && (
              <div>
                <h2 className="text-xl font-bold mb-6">Horários de Funcionamento</h2>
                <div className="space-y-4">
                  {Object.entries(settings.businessHours).map(([day, hours]) => (
                    <div key={day} className="flex items-center space-x-4">
                      <div className="w-32">
                        <span className="text-sm font-medium">{dayNames[day]}</span>
                      </div>
                      
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={hours.closed}
                          onChange={(e) => handleBusinessHoursChange(day, 'closed', e.target.checked)}
                          className="mr-2"
                        />
                        <span className="text-sm">Fechado</span>
                      </label>

                      {!hours.closed && (
                        <>
                          <div>
                            <input
                              type="time"
                              value={hours.open}
                              onChange={(e) => handleBusinessHoursChange(day, 'open', e.target.value)}
                              className="input w-32"
                            />
                          </div>
                          <span className="text-sm">às</span>
                          <div>
                            <input
                              type="time"
                              value={hours.close}
                              onChange={(e) => handleBusinessHoursChange(day, 'close', e.target.value)}
                              className="input w-32"
                            />
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;