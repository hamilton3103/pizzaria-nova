import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Edit, Trash2, Eye, ToggleLeft, ToggleRight } from 'lucide-react';
import { apiService } from '../../services/api';
import { toast } from 'react-hot-toast';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  promo_price?: number | null;
  image: string;
  category_id: string;
  category_name?: string;
  category_slug?: string;
  is_active: boolean;
  is_featured: boolean;
  is_popular: boolean;
  created_at: string;
  updated_at: string;
}

const AdminProducts: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    loadProducts();
  }, [selectedCategory, searchQuery]);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const params: any = {};
      
      if (selectedCategory !== 'all') {
        params.category = selectedCategory;
      }
      
      if (searchQuery.trim()) {
        params.search = searchQuery.trim();
      }

      const response = await apiService.getProducts(params);
      
      if (response.success) {
        setProducts(response.data);
        setError(null);
      } else {
        throw new Error(response.message);
      }
    } catch (err: any) {
      setError(err.message || 'Falha ao carregar produtos');
      console.error('Error loading products:', err);
      toast.error('Erro ao carregar produtos');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Tem certeza que deseja excluir este produto?')) return;

    try {
      const response = await apiService.deleteProduct(id);
      
      if (response.success) {
        setProducts(products.filter(p => p.id !== id));
        toast.success('Produto excluído com sucesso');
      } else {
        throw new Error(response.message);
      }
    } catch (err: any) {
      console.error('Error deleting product:', err);
      toast.error(err.message || 'Erro ao excluir produto');
    }
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const formData = new FormData();
      formData.append('is_active', (!currentStatus).toString());

      const response = await apiService.updateProduct(id, formData);
      
      if (response.success) {
        setProducts(products.map(p => 
          p.id === id ? { ...p, is_active: !currentStatus } : p
        ));
        toast.success('Status do produto atualizado');
      } else {
        throw new Error(response.message);
      }
    } catch (err: any) {
      console.error('Error updating product status:', err);
      toast.error(err.message || 'Erro ao atualizar status do produto');
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  const getCategoryName = (categorySlug: string) => {
    const categories: Record<string, string> = {
      pizza: 'Pizza',
      lanche: 'Lanche',
      bebida: 'Bebida',
      promocao: 'Promoção',
      sobremesa: 'Sobremesa'
    };
    return categories[categorySlug] || categorySlug;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">Gerenciar Produtos</h1>
        <Link to="/admin/products/add" className="btn btn-primary inline-flex items-center">
          <Plus size={20} className="mr-1" />
          Adicionar Produto
        </Link>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Buscar produtos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pr-10 w-full"
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-500">
              <Search size={20} />
            </div>
          </div>
          
          <div className="w-full md:w-48">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="input w-full"
            >
              <option value="all">Todas as Categorias</option>
              <option value="pizza">Pizzas</option>
              <option value="lanche">Lanches</option>
              <option value="bebida">Bebidas</option>
              <option value="promocao">Promoções</option>
              <option value="sobremesa">Sobremesas</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Products Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-neutral-100">
                <th className="px-4 py-3 text-left">Produto</th>
                <th className="px-4 py-3 text-left">Categoria</th>
                <th className="px-4 py-3 text-left">Preço</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Ativo</th>
                <th className="px-4 py-3 text-left">Ações</th>
              </tr>
            </thead>
            <tbody>
              {products.length > 0 ? (
                products.map((product) => (
                  <tr key={product.id} className="border-t border-gray-200">
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-md overflow-hidden mr-3">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="h-full w-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40x40?text=IMG';
                            }}
                          />
                        </div>
                        <div>
                          <span className="font-medium">{product.name}</span>
                          <p className="text-sm text-gray-500 line-clamp-1">
                            {product.description}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`category-badge badge-${product.category_slug || 'default'}`}>
                        {product.category_name || getCategoryName(product.category_slug || '')}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {product.promo_price ? (
                        <div>
                          <span className="line-through text-neutral-500 text-sm">
                            {formatPrice(product.price)}
                          </span>
                          <span className="ml-2 text-primary font-medium">
                            {formatPrice(product.promo_price)}
                          </span>
                        </div>
                      ) : (
                        formatPrice(product.price)
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-1">
                        {product.is_featured && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                            Destaque
                          </span>
                        )}
                        {product.is_popular && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                            Popular
                          </span>
                        )}
                        {!product.is_featured && !product.is_popular && (
                          <span className="px-2 py-1 bg-neutral-100 text-neutral-800 rounded-full text-xs">
                            Normal
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleActive(product.id, product.is_active)}
                        className={`transition-colors ${
                          product.is_active ? 'text-green-600' : 'text-gray-400'
                        }`}
                      >
                        {product.is_active ? (
                          <ToggleRight size={24} />
                        ) : (
                          <ToggleLeft size={24} />
                        )}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-2">
                        <Link
                          to={`/product/${product.id}`}
                          className="p-1 text-neutral-600 hover:text-primary transition-colors"
                          title="Visualizar"
                        >
                          <Eye size={18} />
                        </Link>
                        <Link
                          to={`/admin/products/edit/${product.id}`}
                          className="p-1 text-neutral-600 hover:text-blue-600 transition-colors"
                          title="Editar"
                        >
                          <Edit size={18} />
                        </Link>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="p-1 text-neutral-600 hover:text-red-600 transition-colors"
                          title="Excluir"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-neutral-500">
                    Nenhum produto encontrado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Total de Produtos</h3>
          <p className="text-3xl font-bold text-primary">{products.length}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Produtos Ativos</h3>
          <p className="text-3xl font-bold text-green-600">
            {products.filter(p => p.is_active).length}
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Em Destaque</h3>
          <p className="text-3xl font-bold text-blue-600">
            {products.filter(p => p.is_featured).length}
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Populares</h3>
          <p className="text-3xl font-bold text-purple-600">
            {products.filter(p => p.is_popular).length}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminProducts;