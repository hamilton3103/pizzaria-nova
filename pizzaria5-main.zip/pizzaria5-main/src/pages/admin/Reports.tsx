import React, { useState, useEffect } from 'react';
import { TrendingUp, DollarSign, ShoppingBag, Users, Calendar, Download, BarChart2, Package, Star } from 'lucide-react';
import { apiService } from '../../services/api';
import { toast } from 'react-hot-toast';

interface SalesData {
  summary: {
    total_orders: number;
    total_revenue: number;
    average_order_value: number;
  };
  daily_sales: Array<{
    date: string;
    orders_count: number;
    revenue: number;
  }>;
  sales_by_status: Array<{
    status: string;
    count: number;
    revenue: number;
  }>;
}

interface PopularProduct {
  id: string;
  name: string;
  image: string;
  price: number;
  total_sold: number;
  orders_count: number;
  total_revenue: number;
}

interface CustomerStats {
  stats: {
    total_customers: number;
    active_customers: number;
    new_customers: number;
  };
  top_customers: Array<{
    id: string;
    name: string;
    email: string;
    total_orders: number;
    total_spent: number;
    last_order_date: string;
  }>;
}

const AdminReports: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [salesData, setSalesData] = useState<SalesData | null>(null);
  const [popularProducts, setPopularProducts] = useState<PopularProduct[]>([]);
  const [customerStats, setCustomerStats] = useState<CustomerStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReportsData();
  }, [selectedPeriod]);

  const loadReportsData = async () => {
    try {
      setLoading(true);
      
      // Load sales report
      const salesResponse = await apiService.getSalesReport(selectedPeriod);
      if (salesResponse.success) {
        setSalesData(salesResponse.data);
      }

      // Load popular products
      const productsResponse = await apiService.getProductsPopularityReport(selectedPeriod);
      if (productsResponse.success) {
        setPopularProducts(productsResponse.data);
      }

      // Load customer stats
      const customersResponse = await apiService.getCustomersReport(selectedPeriod);
      if (customersResponse.success) {
        setCustomerStats(customersResponse.data);
      }

    } catch (error: any) {
      console.error('Error loading reports data:', error);
      toast.error('Erro ao carregar relatórios');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const exportReport = () => {
    // Mock export functionality
    toast.success('Relatório exportado com sucesso!');
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'preparing': return 'Preparando';
      case 'out_for_delivery': return 'Saiu para entrega';
      case 'delivered': return 'Entregue';
      case 'canceled': return 'Cancelado';
      default: return status;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold mb-4 md:mb-0">Relatórios</h1>
        <button 
          onClick={exportReport}
          className="btn btn-primary inline-flex items-center"
        >
          <Download size={20} className="mr-1" />
          Exportar Relatório
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <div className="w-full md:w-48">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Período
            </label>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="input w-full"
            >
              <option value="7">Últimos 7 dias</option>
              <option value="30">Últimos 30 dias</option>
              <option value="90">Últimos 90 dias</option>
              <option value="365">Último ano</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Vendas Totais</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">
                {formatCurrency(salesData?.summary.total_revenue || 0)}
              </h3>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <DollarSign size={24} className="text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <TrendingUp size={16} className="mr-1" />
              +12.5%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total de Pedidos</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">{salesData?.summary.total_orders || 0}</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <ShoppingBag size={24} className="text-blue-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <TrendingUp size={16} className="mr-1" />
              +8.2%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Ticket Médio</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">
                {formatCurrency(salesData?.summary.average_order_value || 0)}
              </h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <BarChart2 size={24} className="text-purple-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <TrendingUp size={16} className="mr-1" />
              +5.1%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Clientes Ativos</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">{customerStats?.stats.active_customers || 0}</h3>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <Users size={24} className="text-orange-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <TrendingUp size={16} className="mr-1" />
              +15.3%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Top Products */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Package size={20} className="mr-2" />
              Produtos Mais Vendidos
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {popularProducts.slice(0, 5).map((product, index) => (
                <div key={product.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">
                      {index + 1}
                    </div>
                    <div className="flex items-center">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-10 h-10 object-cover rounded mr-3"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40x40?text=IMG';
                        }}
                      />
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-gray-500">{product.total_sold} vendas</p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(product.total_revenue)}</p>
                    <p className="text-sm text-gray-500">{product.orders_count} pedidos</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sales by Status */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <BarChart2 size={20} className="mr-2" />
              Vendas por Status
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {salesData?.sales_by_status.map((statusData, index) => (
                <div key={statusData.status} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full mr-3" style={{
                      backgroundColor: ['#10B981', '#3B82F6', '#F59E0B', '#8B5CF6', '#EF4444'][index % 5]
                    }}></div>
                    <div>
                      <p className="font-medium">{getStatusText(statusData.status)}</p>
                      <p className="text-sm text-gray-500">{statusData.count} pedidos</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(statusData.revenue)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Daily Sales and Top Customers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Sales */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Calendar size={20} className="mr-2" />
              Vendas Diárias
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {salesData?.daily_sales.slice(0, 7).map((day, index) => (
                <div key={day.date} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar size={16} className="text-gray-400 mr-3" />
                    <div>
                      <p className="font-medium">{formatDate(day.date)}</p>
                      <p className="text-sm text-gray-500">{day.orders_count} pedidos</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(day.revenue)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white rounded-lg shadow-md border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 flex items-center">
              <Star size={20} className="mr-2" />
              Melhores Clientes
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {customerStats?.top_customers.slice(0, 5).map((customer, index) => (
                <div key={customer.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-sm text-gray-500">{customer.total_orders} pedidos</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(customer.total_spent)}</p>
                    <p className="text-sm text-gray-500">
                      Último: {formatDate(customer.last_order_date)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminReports;