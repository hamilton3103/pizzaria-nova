import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Package, DollarSign, ArrowUp, ShoppingBag, Star, Database, Eye } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { dataService } from '../../services/supabase';
import { toast } from 'react-hot-toast';

interface DashboardStats {
  totalProducts: number;
  totalOrders: number;
  totalUsers: number;
  totalRevenue: number;
}

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalProducts: 0,
    totalOrders: 0,
    totalUsers: 0,
    totalRevenue: 0
  });
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load products
      const products = await dataService.getProducts();
      
      // Load orders
      const orders = await dataService.getOrders();
      
      // Load users
      const users = await dataService.getUsers();

      // Calculate stats
      const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0);

      setStats({
        totalProducts: products.length,
        totalOrders: orders.length,
        totalUsers: users.length,
        totalRevenue
      });

      // Set recent orders (last 5)
      setRecentOrders(orders.slice(0, 5));

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Erro ao carregar dados do dashboard');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'preparing':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800';
      case 'out_for_delivery':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'canceled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'preparing': return 'Preparando';
      case 'out_for_delivery': return 'Saiu para entrega';
      case 'delivered': return 'Entregue';
      case 'canceled': return 'Cancelado';
      default: return status;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-primary to-primary-dark rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">
              Bem-vindo, {user?.name}! 👋
            </h1>
            <p className="text-primary-light">
              Aqui está um resumo do seu negócio hoje.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Database size={20} />
            <span className="text-sm">
              DB: ✅ Supabase Conectado
            </span>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Vendas Totais</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">
                {formatCurrency(stats.totalRevenue)}
              </h3>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <DollarSign size={24} className="text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <ArrowUp size={16} className="mr-1" />
              12.5%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total de Pedidos</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">{stats.totalOrders}</h3>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <ShoppingBag size={24} className="text-blue-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <ArrowUp size={16} className="mr-1" />
              8.2%
            </span>
            <span className="text-gray-500 ml-2">vs. período anterior</span>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Total de Usuários</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">{stats.totalUsers}</h3>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <Users size={24} className="text-purple-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="flex items-center text-green-600">
              <ArrowUp size={16} className="mr-1" />
              24%
            </span>
            <span className="text-gray-500 ml-2">este mês</span>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-600 text-sm font-medium">Produtos Ativos</p>
              <h3 className="text-2xl font-bold mt-1 text-gray-900">{stats.totalProducts}</h3>
            </div>
            <div className="bg-orange-100 p-3 rounded-full">
              <Package size={24} className="text-orange-600" />
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="text-gray-500">Ticket médio:</span>
            <span className="font-medium ml-1">
              {formatCurrency(stats.totalOrders > 0 ? stats.totalRevenue / stats.totalOrders : 0)}
            </span>
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-lg shadow-md border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Pedidos Recentes</h2>
            <button 
              onClick={() => window.location.href = '/admin/orders'}
              className="text-primary hover:text-primary-dark font-medium text-sm flex items-center"
            >
              <Eye size={16} className="mr-1" />
              Ver todos
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pedido
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data/Hora
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentOrders.length > 0 ? (
                recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-medium text-gray-900">#{order.id.slice(-8)}</span>
                      <p className="text-xs text-gray-500">{order.order_items?.length || 0} itens</p>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <span className="text-gray-900">{order.users?.name || 'Cliente'}</span>
                        <p className="text-xs text-gray-500">{order.users?.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-gray-500">{formatDate(order.created_at)}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-medium text-gray-900">
                        {formatCurrency(order.total)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.status)}`}>
                        {getStatusText(order.status)}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-gray-500">
                    Nenhum pedido encontrado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex items-center mb-4">
            <Package className="h-8 w-8 text-primary mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Produtos</h3>
          </div>
          <p className="text-gray-600 mb-4">Gerencie seu cardápio e estoque</p>
          <button 
            onClick={() => window.location.href = '/admin/products'}
            className="btn btn-primary w-full"
          >
            Gerenciar Produtos
          </button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex items-center mb-4">
            <ShoppingBag className="h-8 w-8 text-blue-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Pedidos</h3>
          </div>
          <p className="text-gray-600 mb-4">Acompanhe e gerencie pedidos</p>
          <button 
            onClick={() => window.location.href = '/admin/orders'}
            className="btn btn-outline w-full"
          >
            Ver Pedidos
          </button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <div className="flex items-center mb-4">
            <TrendingUp className="h-8 w-8 text-green-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Relatórios</h3>
          </div>
          <p className="text-gray-600 mb-4">Analise vendas e performance</p>
          <button 
            onClick={() => window.location.href = '/admin/reports'}
            className="btn btn-outline w-full"
          >
            Ver Relatórios
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;