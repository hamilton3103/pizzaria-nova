import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, X } from 'lucide-react';
import { apiService } from '../../services/api';
import { toast } from 'react-hot-toast';

interface ProductFormData {
  name: string;
  description: string;
  price: string;
  promo_price: string;
  category_id: string;
  is_active: boolean;
  is_featured: boolean;
  is_popular: boolean;
}

const AddProduct: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  
  const [productData, setProductData] = useState<ProductFormData>({
    name: '',
    description: '',
    price: '',
    promo_price: '',
    category_id: 'cat_pizza_001',
    is_active: true,
    is_featured: false,
    is_popular: false,
  });

  const categories = [
    { id: 'cat_pizza_001', name: 'Pizza' },
    { id: 'cat_lanche_002', name: 'Lanche' },
    { id: 'cat_bebida_003', name: 'Bebida' },
    { id: 'cat_promocao_004', name: 'Promoção' },
    { id: 'cat_sobremesa_005', name: 'Sobremesa' },
  ];
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const target = e.target as HTMLInputElement;
      setProductData({
        ...productData,
        [name]: target.checked,
      });
    } else {
      setProductData({
        ...productData,
        [name]: value,
      });
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview('');
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!imageFile) {
      toast.error('Por favor, selecione uma imagem para o produto');
      return;
    }

    try {
      setLoading(true);

      // Create FormData for file upload
      const formData = new FormData();
      formData.append('name', productData.name);
      formData.append('description', productData.description);
      formData.append('price', productData.price);
      if (productData.promo_price) {
        formData.append('promo_price', productData.promo_price);
      }
      formData.append('category_id', productData.category_id);
      formData.append('is_active', productData.is_active.toString());
      formData.append('is_featured', productData.is_featured.toString());
      formData.append('is_popular', productData.is_popular.toString());
      formData.append('image', imageFile);

      const response = await apiService.createProduct(formData);
      
      if (response.success) {
        toast.success('Produto criado com sucesso!');
        navigate('/admin/products');
      } else {
        throw new Error(response.message);
      }
    } catch (error: any) {
      console.error('Error creating product:', error);
      toast.error(error.message || 'Erro ao criar produto');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div>
      <div className="flex items-center mb-6">
        <Link to="/admin/products" className="text-primary hover:underline mr-4">
          <ArrowLeft size={20} className="inline mr-1" />
          Voltar
        </Link>
        <h1 className="text-2xl font-bold">Adicionar Produto</h1>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Informações Básicas</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-neutral-700 mb-1">
                Nome *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={productData.name}
                onChange={handleChange}
                required
                className="input"
              />
            </div>
            
            <div>
              <label htmlFor="category_id" className="block text-sm font-medium text-neutral-700 mb-1">
                Categoria *
              </label>
              <select
                id="category_id"
                name="category_id"
                value={productData.category_id}
                onChange={handleChange}
                required
                className="input"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="mb-6">
            <label htmlFor="description" className="block text-sm font-medium text-neutral-700 mb-1">
              Descrição *
            </label>
            <textarea
              id="description"
              name="description"
              value={productData.description}
              onChange={handleChange}
              required
              rows={3}
              className="input"
            ></textarea>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-neutral-700 mb-1">
                Preço (R$) *
              </label>
              <input
                type="number"
                id="price"
                name="price"
                value={productData.price}
                onChange={handleChange}
                required
                min="0"
                step="0.01"
                className="input"
              />
            </div>
            
            <div>
              <label htmlFor="promo_price" className="block text-sm font-medium text-neutral-700 mb-1">
                Preço Promocional (R$)
              </label>
              <input
                type="number"
                id="promo_price"
                name="promo_price"
                value={productData.promo_price}
                onChange={handleChange}
                min="0"
                step="0.01"
                className="input"
              />
            </div>
          </div>

          {/* Image Upload */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Imagem do Produto *
            </label>
            
            {!imagePreview ? (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 mb-2">Clique para selecionar uma imagem</p>
                <p className="text-sm text-gray-500">PNG, JPG até 5MB</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
            ) : (
              <div className="relative">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-48 object-cover rounded-lg"
                />
                <button
                  type="button"
                  onClick={removeImage}
                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                >
                  <X size={16} />
                </button>
              </div>
            )}
          </div>
          
          <div className="flex space-x-6">
            <label className="flex items-center">
              <input
                type="checkbox"
                name="is_active"
                checked={productData.is_active}
                onChange={handleChange}
                className="mr-2"
              />
              <span className="text-sm text-neutral-700">Produto Ativo</span>
            </label>
            
            <label className="flex items-center">
              <input
                type="checkbox"
                name="is_featured"
                checked={productData.is_featured}
                onChange={handleChange}
                className="mr-2"
              />
              <span className="text-sm text-neutral-700">Produto em Destaque</span>
            </label>

            <label className="flex items-center">
              <input
                type="checkbox"
                name="is_popular"
                checked={productData.is_popular}
                onChange={handleChange}
                className="mr-2"
              />
              <span className="text-sm text-neutral-700">Produto Popular</span>
            </label>
          </div>
        </div>
        
        <div className="flex justify-end space-x-4">
          <Link to="/admin/products" className="btn btn-outline">
            Cancelar
          </Link>
          <button 
            type="submit" 
            disabled={loading}
            className="btn btn-primary"
          >
            {loading ? 'Salvando...' : 'Salvar Produto'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddProduct;