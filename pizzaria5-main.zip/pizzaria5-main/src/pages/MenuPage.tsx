import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { useProducts } from '../hooks/useProducts';

const MenuPage: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const [searchQuery, setSearchQuery] = useState('');
  
  const { products, isLoading, error } = useProducts({
    category: category,
    search: searchQuery.trim() || undefined,
    active: true
  });
  
  const getCategoryTitle = () => {
    switch (category) {
      case 'pizzas':
        return 'Pizzas';
      case 'lanches':
        return 'Lanches';
      case 'bebidas':
        return 'Bebidas';
      case 'promocoes':
        return 'Promoções';
      case 'sobremesas':
        return 'Sobremesas';
      default:
        return 'Produtos';
    }
  };
  
  const getCategoryDescription = () => {
    switch (category) {
      case 'pizzas':
        return 'Nossas pizzas são preparadas com ingredientes frescos e de alta qualidade. Massas artesanais, molhos caseiros e coberturas generosas.';
      case 'lanches':
        return 'Lanches deliciosos e saborosos. Hambúrgueres artesanais e baguetes recheadas para satisfazer seu apetite.';
      case 'bebidas':
        return 'Bebidas geladas para acompanhar seu pedido. Refrigerantes, sucos, cervejas e muito mais.';
      case 'promocoes':
        return 'Aproveite nossas promoções exclusivas e economize em seu pedido. Ofertas por tempo limitado!';
      case 'sobremesas':
        return 'Deliciosas sobremesas para adoçar seu dia. Opções irresistíveis para finalizar sua refeição com chave de ouro.';
      default:
        return '';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-red-600">Erro ao carregar produtos. Tente novamente.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      {/* Header */}
      <section className="bg-neutral-100 py-8">
        <div className="container mx-auto px-4 md:px-0">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{getCategoryTitle()}</h1>
          <p className="text-neutral-600 mb-6 max-w-3xl">{getCategoryDescription()}</p>
          
          {/* Search */}
          <div className="max-w-md">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input pr-10 w-full"
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-500">
                <Search size={20} />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Products */}
      <section className="py-8">
        <div className="container mx-auto px-4 md:px-0">
          {products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xl text-neutral-600">Nenhum produto encontrado.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default MenuPage;