import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

const CartPage: React.FC = () => {
  const { items, removeFromCart, updateQuantity, subtotal, deliveryFee, total } = useCart();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };
  
  const handleCheckout = () => {
    if (!isAuthenticated) {
      navigate('/login?redirect=checkout');
    } else {
      navigate('/checkout');
    }
  };
  
  return (
    <div className="bg-neutral-100 min-h-screen py-8">
      <div className="container mx-auto px-4 md:px-0">
        <Link to="/" className="flex items-center text-primary hover:underline mb-6">
          <ArrowLeft size={20} className="mr-1" />
          Continuar Comprando
        </Link>
        
        <h1 className="text-3xl font-bold mb-8">Seu Carrinho</h1>
        
        {items.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {items.map((item, index) => (
                  <div key={index} className="p-4 border-b border-gray-200 last:border-b-0">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-24 h-24 rounded-lg overflow-hidden mb-4 md:mb-0">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="md:ml-4 flex-1">
                        <div className="flex justify-between mb-2">
                          <h3 className="font-semibold">{item.product.name}</h3>
                          <button
                            onClick={() => removeFromCart(index)}
                            className="text-neutral-500 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                        
                        {item.selectedOptions && item.selectedOptions.length > 0 && (
                          <p className="text-sm text-neutral-600 mb-2">
                            Opção: {item.selectedOptions[0].name}
                            {item.selectedOptions[0].price > 0 && (
                              <span className="ml-1">
                                (+{formatPrice(item.selectedOptions[0].price)})
                              </span>
                            )}
                          </p>
                        )}
                        
                        {item.notes && (
                          <p className="text-sm text-neutral-600 mb-2">
                            Observação: {item.notes}
                          </p>
                        )}
                        
                        <div className="flex justify-between items-center mt-4">
                          <div className="flex items-center">
                            <button
                              onClick={() => updateQuantity(index, item.quantity - 1)}
                              className="bg-neutral-200 hover:bg-neutral-300 p-1 rounded-l-md transition-colors"
                            >
                              <Minus size={16} />
                            </button>
                            <span className="px-3 py-1 bg-neutral-100 text-sm font-medium">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(index, item.quantity + 1)}
                              className="bg-neutral-200 hover:bg-neutral-300 p-1 rounded-r-md transition-colors"
                            >
                              <Plus size={16} />
                            </button>
                          </div>
                          
                          <div className="text-right">
                            <p className="font-semibold">
                              {formatPrice(
                                ((item.product.promoPrice || item.product.price) +
                                  (item.selectedOptions?.[0]?.price || 0)) *
                                  item.quantity
                              )}
                            </p>
                            {item.quantity > 1 && (
                              <p className="text-xs text-neutral-500">
                                {formatPrice(
                                  (item.product.promoPrice || item.product.price) +
                                    (item.selectedOptions?.[0]?.price || 0)
                                )}{' '}
                                cada
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Order Summary */}
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
                <h2 className="text-xl font-bold mb-6">Resumo do Pedido</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de entrega</span>
                    <span>{formatPrice(deliveryFee)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4 flex justify-between font-bold">
                    <span>Total</span>
                    <span className="text-xl">{formatPrice(total)}</span>
                  </div>
                </div>
                
                <button
                  onClick={handleCheckout}
                  className="btn btn-primary w-full flex items-center justify-center"
                >
                  <ShoppingBag size={20} className="mr-2" />
                  Finalizar Pedido
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="flex justify-center mb-4">
              <ShoppingBag size={64} className="text-neutral-300" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Seu carrinho está vazio</h2>
            <p className="text-neutral-600 mb-6">
              Adicione alguns produtos deliciosos e volte aqui para finalizar seu pedido.
            </p>
            <Link to="/" className="btn btn-primary">
              Explorar Cardápio
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;