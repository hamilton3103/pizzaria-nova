import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Minus, Plus, ArrowLeft } from 'lucide-react';
import { useProduct, useProducts } from '../hooks/useProducts';
import { useCart } from '../contexts/CartContext';
import ProductCard from '../components/ProductCard';

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedOption, setSelectedOption] = useState<any>(undefined);
  const [notes, setNotes] = useState('');
  
  const { product, isLoading, error } = useProduct(id!);
  const { products: relatedProducts } = useProducts({
    category: product?.categories?.slug,
    active: true
  });
  
  const handleAddToCart = () => {
    if (product) {
      const selectedOptions = selectedOption ? [selectedOption] : undefined;
      addToCart(product, quantity, selectedOptions, notes);
    }
  };
  
  const incrementQuantity = () => {
    setQuantity(quantity + 1);
  };
  
  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto py-16 px-4 md:px-0">
        <div className="text-center">
          <p className="text-xl text-neutral-600">Produto não encontrado.</p>
          <Link to="/" className="btn btn-primary mt-4">
            Voltar para a página inicial
          </Link>
        </div>
      </div>
    );
  }

  const filteredRelatedProducts = relatedProducts
    .filter(p => p.id !== product.id)
    .slice(0, 4);
  
  return (
    <div className="bg-white">
      <div className="container mx-auto py-8 px-4 md:px-0">
        <Link 
          to={`/menu/${product.categories?.slug || 'pizzas'}`} 
          className="flex items-center text-primary hover:underline mb-6"
        >
          <ArrowLeft size={20} className="mr-1" />
          Voltar para {product.categories?.name || 'Produtos'}
        </Link>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="rounded-lg overflow-hidden shadow-md">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-auto object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=600';
              }}
            />
          </div>
          
          {/* Product Details */}
          <div>
            <div className="mb-4">
              <span className={`category-badge badge-${product.categories?.slug || 'default'} mb-2`}>
                {product.categories?.name || 'Produto'}
              </span>
              <h1 className="text-3xl font-bold">{product.name}</h1>
            </div>
            
            <p className="text-neutral-600 mb-6">{product.description}</p>
            
            {/* Price */}
            <div className="mb-6">
              {product.promo_price ? (
                <div className="flex items-center">
                  <span className="text-neutral-500 line-through text-lg mr-2">
                    {formatPrice(product.price)}
                  </span>
                  <span className="text-primary font-bold text-3xl">
                    {formatPrice(product.promo_price)}
                  </span>
                </div>
              ) : (
                <span className="text-3xl font-bold">{formatPrice(product.price)}</span>
              )}
            </div>
            
            {/* Ingredients */}
            {product.product_ingredients && product.product_ingredients.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Ingredientes:</h3>
                <ul className="list-disc list-inside text-neutral-600">
                  {product.product_ingredients.map((ingredient: any, index: number) => (
                    <li key={index}>{ingredient.name}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {/* Options */}
            {product.product_options && product.product_options.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Opções:</h3>
                <div className="space-y-2">
                  {product.product_options.map((option: any) => (
                    <label
                      key={option.id}
                      className={`block px-4 py-3 rounded-md border cursor-pointer transition-colors ${
                        selectedOption?.id === option.id
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-300 hover:border-primary'
                      }`}
                    >
                      <input
                        type="radio"
                        name="option"
                        value={option.id}
                        checked={selectedOption?.id === option.id}
                        onChange={() => setSelectedOption(option)}
                        className="sr-only"
                      />
                      <div className="flex justify-between">
                        <span>{option.name}</span>
                        {option.price > 0 && (
                          <span className="font-medium">
                            + {formatPrice(option.price)}
                          </span>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}
            
            {/* Notes */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Observações:</h3>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Alguma observação para o seu pedido? Ex: tirar cebola, sem azeitona, etc."
                className="input h-24 resize-none"
              ></textarea>
            </div>
            
            {/* Quantity */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Quantidade:</h3>
              <div className="flex items-center">
                <button
                  onClick={decrementQuantity}
                  className="bg-neutral-200 hover:bg-neutral-300 p-2 rounded-l-md transition-colors"
                >
                  <Minus size={20} />
                </button>
                <span className="px-6 py-2 bg-neutral-100 text-lg font-medium">
                  {quantity}
                </span>
                <button
                  onClick={incrementQuantity}
                  className="bg-neutral-200 hover:bg-neutral-300 p-2 rounded-r-md transition-colors"
                >
                  <Plus size={20} />
                </button>
              </div>
            </div>
            
            {/* Add to Cart */}
            <button
              onClick={handleAddToCart}
              className="btn btn-primary w-full flex items-center justify-center"
            >
              <ShoppingCart size={20} className="mr-2" />
              Adicionar ao Carrinho
            </button>
          </div>
        </div>
        
        {/* Related Products */}
        {filteredRelatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Produtos Relacionados</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredRelatedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductPage;