import { Product } from '../types';

// Mock product data - this will be replaced by database queries
export const products: Product[] = [
  // Pizzas
  {
    id: 1,
    name: 'Pizza Margherita',
    description: 'Molho de tomate, mussarela, tomate e manjericão fresco.',
    price: 49.90,
    image: 'https://images.pexels.com/photos/825661/pexels-photo-825661.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'pizza',
    ingredients: ['Molho de tomate', 'Mussarela', 'Tomate', 'Manjericão'],
    options: [
      { id: 1, name: 'Média (8 fatias)', price: 0 },
      { id: 2, name: 'Grande (12 fatias)', price: 10 },
    ],
    popular: true,
  },
  {
    id: 2,
    name: 'Pizza Calabresa',
    description: 'Molho de tomate, mussarela e calabresa fatiada.',
    price: 52.90,
    image: 'https://images.pexels.com/photos/4109111/pexels-photo-4109111.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'pizza',
    ingredients: ['Molho de tomate', 'Mussarela', 'Calabresa'],
    options: [
      { id: 1, name: 'Média (8 fatias)', price: 0 },
      { id: 2, name: 'Grande (12 fatias)', price: 10 },
    ],
    popular: true,
  },
  {
    id: 3,
    name: 'Pizza Frango com Catupiry',
    description: 'Molho de tomate, mussarela, frango desfiado e catupiry.',
    price: 55.90,
    promoPrice: 49.90,
    image: 'https://images.pexels.com/photos/905847/pexels-photo-905847.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'pizza',
    ingredients: ['Molho de tomate', 'Mussarela', 'Frango desfiado', 'Catupiry'],
    options: [
      { id: 1, name: 'Média (8 fatias)', price: 0 },
      { id: 2, name: 'Grande (12 fatias)', price: 10 },
    ],
    promo: true,
  },
  {
    id: 4,
    name: 'Pizza Portuguesa',
    description: 'Molho de tomate, mussarela, presunto, ovos, cebola, azeitona e ervilha.',
    price: 54.90,
    image: 'https://images.pexels.com/photos/6697459/pexels-photo-6697459.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'pizza',
    ingredients: ['Molho de tomate', 'Mussarela', 'Presunto', 'Ovos', 'Cebola', 'Azeitona', 'Ervilha'],
    options: [
      { id: 1, name: 'Média (8 fatias)', price: 0 },
      { id: 2, name: 'Grande (12 fatias)', price: 10 },
    ],
  },
  
  // Lanches
  {
    id: 5,
    name: 'Hambúrguer Clássico',
    description: 'Pão, hambúrguer de carne, queijo, alface, tomate, cebola e molho especial.',
    price: 25.90,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'lanche',
    ingredients: ['Pão', 'Hambúrguer de carne', 'Queijo', 'Alface', 'Tomate', 'Cebola', 'Molho especial'],
    popular: true,
  },
  {
    id: 6,
    name: 'Baguete de Carne',
    description: 'Baguete, carne, queijo, alface, tomate e maionese.',
    price: 28.90,
    promoPrice: 24.90,
    image: 'https://images.pexels.com/photos/1603901/pexels-photo-1603901.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'lanche',
    ingredients: ['Baguete', 'Carne', 'Queijo', 'Alface', 'Tomate', 'Maionese'],
    promo: true,
  },
  {
    id: 7,
    name: 'Hambúrguer Especial',
    description: 'Pão, 2 hambúrgueres de carne, bacon, queijo cheddar, cebola caramelizada e molho barbecue.',
    price: 32.90,
    image: 'https://images.pexels.com/photos/2983101/pexels-photo-2983101.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'lanche',
    ingredients: ['Pão', 'Hambúrguer de carne (2)', 'Bacon', 'Queijo cheddar', 'Cebola caramelizada', 'Molho barbecue'],
  },
  
  // Bebidas
  {
    id: 8,
    name: 'Refrigerante 2L',
    description: 'Coca-Cola, Guaraná Antarctica, Fanta, Sprite ou Pepsi.',
    price: 12.90,
    image: 'https://images.pexels.com/photos/2983100/pexels-photo-2983100.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'bebida',
    options: [
      { id: 1, name: 'Coca-Cola', price: 0 },
      { id: 2, name: 'Guaraná Antarctica', price: 0 },
      { id: 3, name: 'Fanta Laranja', price: 0 },
      { id: 4, name: 'Sprite', price: 0 },
      { id: 5, name: 'Pepsi', price: 0 },
    ],
  },
  {
    id: 9,
    name: 'Suco Natural 500ml',
    description: 'Laranja, Limão, Abacaxi ou Maracujá.',
    price: 9.90,
    image: 'https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'bebida',
    options: [
      { id: 1, name: 'Laranja', price: 0 },
      { id: 2, name: 'Limão', price: 0 },
      { id: 3, name: 'Abacaxi', price: 0 },
      { id: 4, name: 'Maracujá', price: 0 },
    ],
  },
  
  // Promoções
  {
    id: 10,
    name: 'Combo Família',
    description: '1 Pizza Grande (12 fatias), 2 Refrigerantes 2L e 1 Borda Recheada.',
    price: 89.90,
    promoPrice: 69.90,
    image: 'https://images.pexels.com/photos/9792458/pexels-photo-9792458.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'promocao',
    options: [
      { id: 1, name: 'Pizza Calabresa', price: 0 },
      { id: 2, name: 'Pizza Margherita', price: 0 },
      { id: 3, name: 'Pizza Frango com Catupiry', price: 0 },
      { id: 4, name: 'Pizza Portuguesa', price: 0 },
    ],
    promo: true,
  },
  {
    id: 11,
    name: 'Combo Especial',
    description: '2 Hambúrgueres Especiais + Batata Frita Grande + Refrigerante 2L.',
    price: 79.90,
    promoPrice: 59.90,
    image: 'https://images.pexels.com/photos/70497/pexels-photo-70497.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'promocao',
    promo: true,
  },
  
  // Sobremesas
  {
    id: 12,
    name: 'Pudim de Leite',
    description: 'Pudim de leite condensado tradicional.',
    price: 15.90,
    image: 'https://images.pexels.com/photos/2531546/pexels-photo-2531546.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'sobremesa',
  },
  {
    id: 13,
    name: 'Petit Gateau',
    description: 'Bolo de chocolate com recheio cremoso e sorvete de creme.',
    price: 18.90,
    image: 'https://images.pexels.com/photos/2144112/pexels-photo-2144112.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'sobremesa',
    popular: true,
  },
];

// Helper functions
export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getPromotions = (): Product[] => {
  return products.filter(product => product.promo);
};

export const getPopularProducts = (): Product[] => {
  return products.filter(product => product.popular);
};

export const searchProducts = (query: string): Product[] => {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(
    product =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery) ||
      (product.ingredients && product.ingredients.some(ingredient => ingredient.toLowerCase().includes(lowercaseQuery)))
  );
};