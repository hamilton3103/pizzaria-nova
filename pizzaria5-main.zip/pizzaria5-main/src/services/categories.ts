import { getMany, getOne, executeQuery } from '../lib/database';

export const categoryService = {
  // Get all categories
  async getAll() {
    const categories = await getMany(
      'SELECT * FROM categories ORDER BY name'
    );
    return categories || [];
  },

  // Get category by slug
  async getBySlug(slug: string) {
    const category = await getOne(
      'SELECT * FROM categories WHERE slug = ?',
      [slug]
    );
    return category;
  },

  // Get category by ID
  async getById(id: string) {
    const category = await getOne(
      'SELECT * FROM categories WHERE id = ?',
      [id]
    );
    return category;
  },

  // Create new category
  async create(categoryData: { name: string; slug: string }) {
    const result = await executeQuery(
      'INSERT INTO categories (id, name, slug) VALUES (UUID(), ?, ?)',
      [categoryData.name, categoryData.slug]
    );
    return result;
  },

  // Update category
  async update(id: string, categoryData: { name?: string; slug?: string }) {
    const fields: string[] = [];
    const params: any[] = [];

    if (categoryData.name !== undefined) {
      fields.push('name = ?');
      params.push(categoryData.name);
    }

    if (categoryData.slug !== undefined) {
      fields.push('slug = ?');
      params.push(categoryData.slug);
    }

    if (fields.length === 0) {
      throw new Error('No fields to update');
    }

    params.push(id);
    const query = `UPDATE categories SET ${fields.join(', ')} WHERE id = ?`;
    
    const result = await executeQuery(query, params);
    return result;
  },

  // Delete category
  async delete(id: string) {
    const result = await executeQuery(
      'DELETE FROM categories WHERE id = ?',
      [id]
    );
    return result;
  }
};