import { Product } from '../types';

// Mock products database
const mockProducts: any[] = [
  {
    id: 'pizza-1',
    name: 'Pizza Margherita',
    description: 'Pizza clássica com molho de tomate, mussarela e manjericão fresco',
    price: 35.90,
    promo_price: null,
    image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg',
    category_id: 'cat-pizza',
    category: 'pizza',
    category_name: 'Pizza',
    category_slug: 'pizza',
    is_active: true,
    is_featured: true,
    is_popular: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    options: [
      { id: 'opt-1', name: 'Pequena', price: 0 },
      { id: 'opt-2', name: 'Média', price: 5 },
      { id: 'opt-3', name: 'Grande', price: 10 }
    ],
    ingredients: ['Molho de tomate', 'Mussarela', 'Manjericão']
  },
  {
    id: 'pizza-2',
    name: 'Pizza Pepperoni',
    description: 'Pizza com molho de tomate, mussarela e pepperoni',
    price: 42.90,
    promo_price: 38.90,
    image: 'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg',
    category_id: 'cat-pizza',
    category: 'pizza',
    category_name: 'Pizza',
    category_slug: 'pizza',
    is_active: true,
    is_featured: false,
    is_popular: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    options: [
      { id: 'opt-4', name: 'Pequena', price: 0 },
      { id: 'opt-5', name: 'Média', price: 5 },
      { id: 'opt-6', name: 'Grande', price: 10 }
    ],
    ingredients: ['Molho de tomate', 'Mussarela', 'Pepperoni']
  },
  {
    id: 'lanche-1',
    name: 'X-Burger Clássico',
    description: 'Hambúrguer artesanal com queijo, alface, tomate e molho especial',
    price: 28.90,
    promo_price: null,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg',
    category_id: 'cat-lanche',
    category: 'lanche',
    category_name: 'Lanche',
    category_slug: 'lanche',
    is_active: true,
    is_featured: false,
    is_popular: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    options: [
      { id: 'opt-7', name: 'Simples', price: 0 },
      { id: 'opt-8', name: 'Duplo', price: 8 }
    ],
    ingredients: ['Pão brioche', 'Hambúrguer 180g', 'Queijo', 'Alface', 'Tomate', 'Molho especial']
  },
  {
    id: 'bebida-1',
    name: 'Coca-Cola 350ml',
    description: 'Refrigerante Coca-Cola gelado',
    price: 6.90,
    promo_price: null,
    image: 'https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg',
    category_id: 'cat-bebida',
    category: 'bebida',
    category_name: 'Bebida',
    category_slug: 'bebida',
    is_active: true,
    is_featured: false,
    is_popular: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    options: [],
    ingredients: []
  }
];

export const productService = {
  // Get all products with optional filters
  async getAll(options?: { 
    category?: string; 
    search?: string;
    featured?: boolean;
    popular?: boolean;
    active?: boolean;
  }) {
    let filteredProducts = [...mockProducts];

    // Apply filters
    if (options?.active !== undefined) {
      filteredProducts = filteredProducts.filter(p => p.is_active === options.active);
    } else {
      filteredProducts = filteredProducts.filter(p => p.is_active === true);
    }

    if (options?.category) {
      filteredProducts = filteredProducts.filter(p => p.category === options.category);
    }

    if (options?.featured) {
      filteredProducts = filteredProducts.filter(p => p.is_featured === true);
    }

    if (options?.popular) {
      filteredProducts = filteredProducts.filter(p => p.is_popular === true);
    }

    if (options?.search) {
      const searchLower = options.search.toLowerCase();
      filteredProducts = filteredProducts.filter(p => 
        p.name.toLowerCase().includes(searchLower) || 
        p.description.toLowerCase().includes(searchLower)
      );
    }

    return filteredProducts;
  },

  // Get a single product by ID
  async getById(id: string) {
    const product = mockProducts.find(p => p.id === id);
    return product || null;
  },

  // Create a new product
  async create(product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) {
    const newProduct = {
      id: `product-${Date.now()}`,
      ...product,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      options: [],
      ingredients: []
    };

    mockProducts.push(newProduct);
    return { id: newProduct.id };
  },

  // Update a product
  async update(id: string, updates: Partial<Product>) {
    const productIndex = mockProducts.findIndex(p => p.id === id);
    
    if (productIndex === -1) {
      throw new Error('Product not found');
    }

    mockProducts[productIndex] = {
      ...mockProducts[productIndex],
      ...updates,
      updated_at: new Date().toISOString()
    };

    return { success: true };
  },

  // Delete a product (soft delete by setting is_active to false)
  async delete(id: string) {
    const productIndex = mockProducts.findIndex(p => p.id === id);
    
    if (productIndex === -1) {
      throw new Error('Product not found');
    }

    mockProducts[productIndex].is_active = false;
    mockProducts[productIndex].updated_at = new Date().toISOString();

    return { success: true };
  },

  // Get product options
  async getOptions(productId: string) {
    const product = mockProducts.find(p => p.id === productId);
    return product?.options || [];
  },

  // Add product option
  async addOption(productId: string, option: { name: string; price: number }) {
    const product = mockProducts.find(p => p.id === productId);
    
    if (!product) {
      throw new Error('Product not found');
    }

    const newOption = {
      id: `opt-${Date.now()}`,
      ...option
    };

    product.options.push(newOption);
    return { id: newOption.id };
  },

  // Get product ingredients
  async getIngredients(productId: string) {
    const product = mockProducts.find(p => p.id === productId);
    return product?.ingredients || [];
  },

  // Add product ingredient
  async addIngredient(productId: string, name: string) {
    const product = mockProducts.find(p => p.id === productId);
    
    if (!product) {
      throw new Error('Product not found');
    }

    product.ingredients.push(name);
    return { success: true };
  }
};