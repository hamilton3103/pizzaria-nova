// Mock auth service for frontend - replace with actual API calls
interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'admin' | 'user';
  created_at: string;
  updated_at: string;
}

// Mock users database
const mockUsers: User[] = [
  {
    id: 'admin-1',
    name: 'Admin',
    email: 'admin@laricas.com',
    role: 'admin',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export const authService = {
  // Test database connection (mock)
  async testDatabase() {
    return true;
  },

  // Register new user
  async register(userData: {
    name: string;
    email: string;
    password: string;
    phone?: string;
  }) {
    try {
      // Check if user already exists
      const existingUser = mockUsers.find(user => user.email === userData.email);
      
      if (existingUser) {
        throw new Error('Email já está em uso');
      }

      // Create new user
      const newUser: User = {
        id: `user-${Date.now()}`,
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        role: 'user',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      mockUsers.push(newUser);

      return { success: true, message: 'Usuário criado com sucesso' };
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  // Login user
  async login(email: string, password: string) {
    try {
      console.log('🔐 Attempting login for:', email);

      // Find user by email
      const user = mockUsers.find(u => u.email === email);

      if (!user) {
        console.log('❌ User not found:', email);
        throw new Error('Credenciais inválidas');
      }

      console.log('✅ User found:', user.email, 'Role:', user.role);

      // For demo purposes, accept any password for existing users
      // In production, this would verify against hashed password
      if (email === 'admin@laricas.com' && password !== 'admin123') {
        console.log('❌ Invalid password for admin');
        throw new Error('Credenciais inválidas');
      }

      console.log('✅ Password valid for:', email);

      // Generate mock token
      const token = `mock-token-${user.id}-${Date.now()}`;

      console.log('✅ Login successful for:', email, 'Token generated');

      return {
        success: true,
        user,
        token
      };
    } catch (error) {
      console.error('❌ Login error:', error);
      throw error;
    }
  },

  // Verify JWT token
  async verifyToken(token: string) {
    try {
      // Extract user ID from mock token
      const parts = token.split('-');
      if (parts.length < 3 || parts[0] !== 'mock' || parts[1] !== 'token') {
        throw new Error('Token inválido');
      }

      const userId = parts[2];
      const user = mockUsers.find(u => u.id === userId);

      if (!user) {
        throw new Error('Usuário não encontrado');
      }

      return { success: true, user };
    } catch (error) {
      console.error('Token verification error:', error);
      throw new Error('Token inválido');
    }
  },

  // Create admin user if not exists
  async ensureAdminUser() {
    try {
      const adminUser = mockUsers.find(u => u.email === 'admin@laricas.com');

      if (!adminUser) {
        console.log('🔧 Admin user already exists in mock data');
      } else {
        console.log('✅ Admin user already exists');
      }
    } catch (error) {
      console.error('❌ Error ensuring admin user:', error);
    }
  }
};