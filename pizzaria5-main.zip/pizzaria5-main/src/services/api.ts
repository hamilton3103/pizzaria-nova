// API service for admin panel with enhanced token management
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

class ApiService {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private refreshPromise: Promise<string> | null = null;

  constructor() {
    this.accessToken = localStorage.getItem('admin_token');
    this.refreshToken = localStorage.getItem('admin_refresh_token');
    
    // Auto-refresh token quando próximo do vencimento
    this.setupTokenRefresh();
  }

  private setupTokenRefresh() {
    // Verificar a cada minuto se o token precisa ser renovado
    setInterval(() => {
      this.checkAndRefreshToken();
    }, 60000); // 1 minuto
  }

  private async checkAndRefreshToken() {
    if (!this.accessToken || !this.refreshToken) return;

    try {
      // Decodificar o token para verificar expiração
      const tokenPayload = JSON.parse(atob(this.accessToken.split('.')[1]));
      const expirationTime = tokenPayload.exp * 1000;
      const currentTime = Date.now();
      const timeUntilExpiry = expirationTime - currentTime;
      
      // Se o token expira em menos de 5 minutos, renovar
      if (timeUntilExpiry < 5 * 60 * 1000) {
        console.log('🔄 Token expiring soon, refreshing...');
        await this.refreshAccessToken();
      }
    } catch (error) {
      console.error('Error checking token expiration:', error);
    }
  }

  private async refreshAccessToken(): Promise<string> {
    // Evitar múltiplas tentativas simultâneas de refresh
    if (this.refreshPromise) {
      return this.refreshPromise;
    }

    this.refreshPromise = this.performTokenRefresh();
    
    try {
      const newToken = await this.refreshPromise;
      return newToken;
    } finally {
      this.refreshPromise = null;
    }
  }

  private async performTokenRefresh(): Promise<string> {
    if (!this.refreshToken) {
      throw new Error('No refresh token available');
    }

    try {
      const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || 'Token refresh failed');
      }

      // Atualizar tokens
      this.accessToken = data.data.accessToken;
      this.refreshToken = data.data.refreshToken;
      
      localStorage.setItem('admin_token', this.accessToken);
      localStorage.setItem('admin_refresh_token', this.refreshToken);
      localStorage.setItem('admin_user', JSON.stringify(data.data.user));

      console.log('✅ Token refreshed successfully');
      return this.accessToken;

    } catch (error) {
      console.error('❌ Token refresh failed:', error);
      this.logout();
      throw error;
    }
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    // Tentar com o token atual primeiro
    let token = this.accessToken;
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    try {
      let response = await fetch(url, config);
      
      // Se o token expirou, tentar renovar e fazer a requisição novamente
      if (response.status === 401 && this.refreshToken) {
        console.log('🔄 Token expired, attempting refresh...');
        
        try {
          token = await this.refreshAccessToken();
          
          // Refazer a requisição com o novo token
          config.headers = {
            ...config.headers,
            Authorization: `Bearer ${token}`,
          };
          
          response = await fetch(url, config);
        } catch (refreshError) {
          console.error('Failed to refresh token:', refreshError);
          throw refreshError;
        }
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Erro na requisição');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Auth methods
  async login(email: string, password: string, rememberMe: boolean = false) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, rememberMe }),
    });

    if (response.success) {
      this.accessToken = response.data.accessToken;
      this.refreshToken = response.data.refreshToken;
      
      localStorage.setItem('admin_token', this.accessToken);
      localStorage.setItem('admin_refresh_token', this.refreshToken);
      localStorage.setItem('admin_user', JSON.stringify(response.data.user));
    }

    return response;
  }

  async logout() {
    try {
      if (this.accessToken) {
        await this.request('/auth/logout', {
          method: 'POST',
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.accessToken = null;
      this.refreshToken = null;
      localStorage.removeItem('admin_token');
      localStorage.removeItem('admin_refresh_token');
      localStorage.removeItem('admin_user');
    }
  }

  async verifyToken() {
    return this.request('/auth/verify', {
      method: 'POST',
    });
  }

  async getCurrentUser() {
    return this.request('/auth/me');
  }

  // Products methods
  async getProducts(params?: {
    category?: string;
    search?: string;
    featured?: boolean;
    popular?: boolean;
    active?: boolean;
  }) {
    const queryParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }

    const endpoint = `/products${queryParams.toString() ? `?${queryParams}` : ''}`;
    return this.request(endpoint);
  }

  async getProduct(id: string) {
    return this.request(`/products/${id}`);
  }

  async createProduct(productData: FormData) {
    return this.request('/products', {
      method: 'POST',
      headers: {
        ...(this.accessToken && { Authorization: `Bearer ${this.accessToken}` }),
      },
      body: productData,
    });
  }

  async updateProduct(id: string, productData: FormData) {
    return this.request(`/products/${id}`, {
      method: 'PUT',
      headers: {
        ...(this.accessToken && { Authorization: `Bearer ${this.accessToken}` }),
      },
      body: productData,
    });
  }

  async deleteProduct(id: string) {
    return this.request(`/products/${id}`, {
      method: 'DELETE',
    });
  }

  // Orders methods
  async getOrders(params?: { status?: string; limit?: number; offset?: number }) {
    const queryParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }

    const endpoint = `/orders${queryParams.toString() ? `?${queryParams}` : ''}`;
    return this.request(endpoint);
  }

  async getOrder(id: string) {
    return this.request(`/orders/${id}`);
  }

  async updateOrderStatus(id: string, status: string) {
    return this.request(`/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  // Users methods
  async getUsers(params?: { role?: string; search?: string }) {
    const queryParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }

    const endpoint = `/users${queryParams.toString() ? `?${queryParams}` : ''}`;
    return this.request(endpoint);
  }

  async createUser(userData: any) {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async updateUser(id: string, userData: any) {
    return this.request(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  }

  // Clients methods
  async getClients(params?: { search?: string; limit?: number; offset?: number }) {
    const queryParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }

    const endpoint = `/clients${queryParams.toString() ? `?${queryParams}` : ''}`;
    return this.request(endpoint);
  }

  async getClient(id: string) {
    return this.request(`/clients/${id}`);
  }

  // Reports methods
  async getSalesReport(period: string = '30') {
    return this.request(`/reports/sales?period=${period}`);
  }

  async getProductsPopularityReport(period: string = '30') {
    return this.request(`/reports/products-popularity?period=${period}`);
  }

  async getCustomersReport(period: string = '30') {
    return this.request(`/reports/customers?period=${period}`);
  }
}

export const apiService = new ApiService();