// This file is kept for compatibility but MySQL is now the primary database
// Remove Supabase imports and use MySQL instead

export const supabase = null;

// Placeholder for backward compatibility
export default null;