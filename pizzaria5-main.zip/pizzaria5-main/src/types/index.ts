export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  role: 'admin' | 'user';
  created_at: Date;
  updated_at: Date;
  addresses?: Address[];
}

export interface Product {
  id: number | string;
  name: string;
  description: string;
  price: number;
  promoPrice?: number;
  image: string;
  category: string;
  category_id?: string;
  ingredients?: string[];
  options?: ProductOption[];
  popular?: boolean;
  promo?: boolean;
  is_active?: boolean;
  is_featured?: boolean;
  is_popular?: boolean;
  created_at?: Date;
  updated_at?: Date;
}

export interface ProductOption {
  id: number | string;
  name: string;
  price: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedOptions?: ProductOption[];
  notes?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  created_at: Date;
  updated_at: Date;
}

export interface Order {
  id: string;
  user_id: string;
  address_id: string;
  status: 'pending' | 'confirmed' | 'preparing' | 'out_for_delivery' | 'delivered' | 'canceled';
  payment_method: 'credit_card' | 'pix' | 'cash';
  subtotal: number;
  delivery_fee: number;
  total: number;
  created_at: Date;
  updated_at: Date;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  notes?: string;
}

export interface Address {
  id: string;
  user_id: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zip_code: string;
  is_default: boolean;
  created_at?: Date;
  updated_at?: Date;
}

export interface Review {
  id: string;
  user_id: string;
  product_id: string;
  rating: number;
  comment: string;
  created_at: Date;
  updated_at: Date;
}