import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiService } from '../services/api';
import { toast } from 'react-hot-toast';

interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  phone?: string;
  createdAt?: string;
}

interface Address {
  id: string;
  user_id: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zip_code: string;
  is_default: boolean;
}

interface AuthContextType {
  user: AuthUser | null;
  session: any | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (name: string, email: string, password: string, phone?: string) => Promise<boolean>;
  loading: boolean;
  addAddress: (address: any) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [session, setSession] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already authenticated
    const checkAuth = async () => {
      try {
        const currentUser = await apiService.getCurrentUser();
        if (currentUser) {
          setUser({
            id: currentUser.id,
            name: currentUser.name,
            email: currentUser.email,
            role: currentUser.role || 'user',
            phone: currentUser.phone,
            createdAt: currentUser.created_at
          });
          setSession({ user: currentUser });
        }
      } catch (error) {
        console.log('No authenticated user found');
        // Clear any invalid tokens
        await apiService.logout();
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true);
      console.log('Attempting login for:', email);
      
      const response = await apiService.login(email, password);
      
      if (response.success && response.user) {
        const userData = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email,
          role: response.user.role || 'user',
          phone: response.user.phone,
          createdAt: response.user.created_at
        };
        
        setUser(userData);
        setSession({ user: response.user });
        
        console.log('Login successful for:', email);
        toast.success('Login realizado com sucesso!');
        return true;
      } else {
        console.error('Login failed:', response.message);
        toast.error(response.message || 'Email ou senha incorretos');
        return false;
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Erro ao fazer login');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string, phone?: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      // Note: The current backend API does not expose a public user registration endpoint.
      // The existing /api/users endpoint is likely protected for administrative use.
      // To enable public registration, a new, publicly accessible endpoint would be required on the backend.
      
      toast.error('Registro não disponível no momento. Entre em contato com o administrador.');
      return false;
    } catch (error) {
      console.error('Registration error:', error);
      toast.error('Erro ao criar conta');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await apiService.logout();
      setUser(null);
      setSession(null);
      toast.success('Logout realizado com sucesso');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Erro ao fazer logout');
    }
  };

  const addAddress = async (addressData: any) => {
    if (!user) return;

    try {
      // Note: The apiService currently lacks a corresponding backend endpoint for adding user addresses.
      // This functionality will require a new endpoint on the backend to be fully implemented.
      
      toast.error('Funcionalidade de endereços não disponível no momento');
    } catch (error) {
      console.error('Error adding address:', error);
      toast.error('Erro ao adicionar endereço');
    }
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        isAuthenticated,
        isAdmin,
        login,
        logout,
        register,
        loading,
        addAddress
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};