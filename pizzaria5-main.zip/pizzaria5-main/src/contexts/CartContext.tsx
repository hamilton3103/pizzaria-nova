import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product, ProductOption } from '../types';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity: number, selectedOptions?: ProductOption[], notes?: string) => void;
  removeFromCart: (index: number) => void;
  updateQuantity: (index: number, quantity: number) => void;
  updateOptions: (index: number, selectedOptions: ProductOption[]) => void;
  updateNotes: (index: number, notes: string) => void;
  clearCart: () => void;
  subtotal: number;
  deliveryFee: number;
  total: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [subtotal, setSubtotal] = useState(0);
  const [deliveryFee, setDeliveryFee] = useState(5); // Default delivery fee
  const [total, setTotal] = useState(0);

  useEffect(() => {
    // Load cart from localStorage on initial render
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setItems(JSON.parse(savedCart));
    }
  }, []);

  useEffect(() => {
    // Save cart to localStorage whenever it changes
    localStorage.setItem('cart', JSON.stringify(items));

    // Calculate subtotal
    const newSubtotal = items.reduce((sum, item) => {
      const itemPrice = item.product.promoPrice || item.product.price;
      const optionsPrice = item.selectedOptions
        ? item.selectedOptions.reduce((total, option) => total + option.price, 0)
        : 0;
      return sum + (itemPrice + optionsPrice) * item.quantity;
    }, 0);

    setSubtotal(newSubtotal);
    setTotal(newSubtotal + deliveryFee);
  }, [items, deliveryFee]);

  const addToCart = (
    product: Product,
    quantity: number,
    selectedOptions?: ProductOption[],
    notes?: string
  ) => {
    // Check if product already exists in cart with same options
    const existingItemIndex = items.findIndex(
      (item) =>
        item.product.id === product.id &&
        JSON.stringify(item.selectedOptions) === JSON.stringify(selectedOptions)
    );

    if (existingItemIndex > -1) {
      // Update quantity if item exists
      const updatedItems = [...items];
      updatedItems[existingItemIndex].quantity += quantity;
      setItems(updatedItems);
    } else {
      // Add new item
      setItems([...items, { product, quantity, selectedOptions, notes }]);
    }
  };

  const removeFromCart = (index: number) => {
    const updatedItems = [...items];
    updatedItems.splice(index, 1);
    setItems(updatedItems);
  };

  const updateQuantity = (index: number, quantity: number) => {
    if (quantity < 1) return; // Don't allow quantity less than 1
    const updatedItems = [...items];
    updatedItems[index].quantity = quantity;
    setItems(updatedItems);
  };

  const updateOptions = (index: number, selectedOptions: ProductOption[]) => {
    const updatedItems = [...items];
    updatedItems[index].selectedOptions = selectedOptions;
    setItems(updatedItems);
  };

  const updateNotes = (index: number, notes: string) => {
    const updatedItems = [...items];
    updatedItems[index].notes = notes;
    setItems(updatedItems);
  };

  const clearCart = () => {
    setItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        updateOptions,
        updateNotes,
        clearCart,
        subtotal,
        deliveryFee,
        total,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};