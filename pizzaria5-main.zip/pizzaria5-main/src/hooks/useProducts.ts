import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { dataService } from '../services/supabase';
import { toast } from 'react-hot-toast';

export const useProducts = (options?: {
  category?: string;
  search?: string;
  featured?: boolean;
  popular?: boolean;
  active?: boolean;
}) => {
  const queryClient = useQueryClient();

  const {
    data: products,
    isLoading,
    error
  } = useQuery({
    queryKey: ['products', options],
    queryFn: () => dataService.getProducts(options),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  return {
    products: products || [],
    isLoading,
    error
  };
};

export const useProduct = (id: string) => {
  const {
    data: product,
    isLoading,
    error
  } = useQuery({
    queryKey: ['product', id],
    queryFn: () => dataService.getProduct(id),
    enabled: !!id,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  return {
    product,
    isLoading,
    error
  };
};

export const useCategories = () => {
  const {
    data: categories,
    isLoading,
    error
  } = useQuery({
    queryKey: ['categories'],
    queryFn: () => dataService.getCategories(),
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  return {
    categories: categories || [],
    isLoading,
    error
  };
};