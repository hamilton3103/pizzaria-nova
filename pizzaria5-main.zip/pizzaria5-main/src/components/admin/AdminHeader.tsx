import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, User, Menu, X, Home, Package, ShoppingBag, Users, BarChart2, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const AdminHeader: React.FC = () => {
  const { user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  
  return (
    <header className="bg-white shadow-sm z-10 border-b border-gray-200">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center md:hidden">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-gray-700 hover:text-primary transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        <div className="flex-1 ml-4 md:ml-0">
          <h1 className="text-xl font-bold text-gray-900">Painel Administrativo</h1>
          <p className="text-sm text-gray-600">Laricas Pizzaria</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative text-gray-700 hover:text-primary transition-colors">
            <Bell size={20} />
            <span className="absolute -top-1 -right-1 bg-primary text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </button>
          
          <div className="relative">
            <button 
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center text-gray-700 hover:text-primary transition-colors space-x-2"
            >
              <div className="h-8 w-8 bg-primary rounded-full flex items-center justify-center text-sm font-medium text-white">
                {user?.name?.charAt(0) || 'A'}
              </div>
              <span className="hidden md:block font-medium">{user?.name || 'Admin'}</span>
            </button>
            
            {isProfileOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50 border border-gray-200">
                <div className="px-4 py-2 border-b border-gray-100">
                  <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                  <p className="text-xs text-gray-500">{user?.email}</p>
                  <span className="inline-block mt-1 px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                    Administrador
                  </span>
                </div>
                <Link
                  to="/"
                  className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                  onClick={() => setIsProfileOpen(false)}
                >
                  <Home size={16} className="mr-2" />
                  Ver Site
                </Link>
                <Link
                  to="/profile"
                  className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                  onClick={() => setIsProfileOpen(false)}
                >
                  <User size={16} className="mr-2" />
                  Meu Perfil
                </Link>
                <Link
                  to="/admin/settings"
                  className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                  onClick={() => setIsProfileOpen(false)}
                >
                  <Settings size={16} className="mr-2" />
                  Configurações
                </Link>
                <button
                  onClick={() => {
                    logout();
                    setIsProfileOpen(false);
                  }}
                  className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut size={16} className="mr-2" />
                  Sair
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-gray-800 text-white animate-fade-in">
          <nav>
            <ul>
              <li>
                <Link
                  to="/admin"
                  className="flex items-center px-6 py-3 hover:bg-gray-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Home size={20} className="mr-3" />
                  <span>Dashboard</span>
                </Link>
              </li>
              
              <li>
                <Link
                  to="/admin/products"
                  className="flex items-center px-6 py-3 hover:bg-gray-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Package size={20} className="mr-3" />
                  <span>Produtos</span>
                </Link>
              </li>
              
              <li>
                <Link
                  to="/admin/orders"
                  className="flex items-center px-6 py-3 hover:bg-gray-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <ShoppingBag size={20} className="mr-3" />
                  <span>Pedidos</span>
                </Link>
              </li>
              
              <li>
                <Link
                  to="/admin/users"
                  className="flex items-center px-6 py-3 hover:bg-gray-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Users size={20} className="mr-3" />
                  <span>Clientes</span>
                </Link>
              </li>
              
              <li>
                <Link
                  to="/admin/reports"
                  className="flex items-center px-6 py-3 hover:bg-gray-700 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <BarChart2 size={20} className="mr-3" />
                  <span>Relatórios</span>
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default AdminHeader;