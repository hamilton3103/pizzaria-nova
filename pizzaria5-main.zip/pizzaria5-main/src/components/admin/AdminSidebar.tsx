import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Package, ShoppingBag, Users, Settings, BarChart2 } from 'lucide-react';

const AdminSidebar: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };
  
  return (
    <div className="bg-neutral-800 text-white w-64 min-h-screen flex-shrink-0 hidden md:block">
      <div className="p-6">
        <Link to="/admin" className="flex items-center">
          <span className="text-xl font-bold">Laricas Admin</span>
        </Link>
      </div>
      
      <nav className="mt-6">
        <ul className="space-y-2">
          <li>
            <Link
              to="/admin"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin') && location.pathname === '/admin' ? 'bg-primary text-white' : ''
              }`}
            >
              <Home size={20} className="mr-3" />
              <span>Dashboard</span>
            </Link>
          </li>
          
          <li>
            <Link
              to="/admin/products"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin/products') ? 'bg-primary text-white' : ''
              }`}
            >
              <Package size={20} className="mr-3" />
              <span>Produtos</span>
            </Link>
          </li>
          
          <li>
            <Link
              to="/admin/orders"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin/orders') ? 'bg-primary text-white' : ''
              }`}
            >
              <ShoppingBag size={20} className="mr-3" />
              <span>Pedidos</span>
            </Link>
          </li>
          
          <li>
            <Link
              to="/admin/users"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin/users') ? 'bg-primary text-white' : ''
              }`}
            >
              <Users size={20} className="mr-3" />
              <span>Clientes</span>
            </Link>
          </li>
          
          <li>
            <Link
              to="/admin/reports"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin/reports') ? 'bg-primary text-white' : ''
              }`}
            >
              <BarChart2 size={20} className="mr-3" />
              <span>Relatórios</span>
            </Link>
          </li>
          
          <li>
            <Link
              to="/admin/settings"
              className={`flex items-center px-6 py-3 hover:bg-neutral-700 transition-colors ${
                isActive('/admin/settings') ? 'bg-primary text-white' : ''
              }`}
            >
              <Settings size={20} className="mr-3" />
              <span>Configurações</span>
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default AdminSidebar;