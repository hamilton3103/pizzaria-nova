import React from 'react';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Plus } from 'lucide-react';
import { toast } from 'react-hot-toast';

const productSchema = z.object({
  name: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres'),
  description: z.string().min(10, 'Descrição deve ter no mínimo 10 caracteres'),
  price: z.number().min(0, 'Preço deve ser maior que 0'),
  promo_price: z.number().min(0).optional().nullable(),
  image: z.string().url('URL da imagem inválida'),
  category_id: z.string().uuid('Categoria inválida'),
  is_active: z.boolean(),
  is_featured: z.boolean(),
  is_popular: z.boolean(),
  ingredients: z.array(z.string()),
  options: z.array(z.object({
    name: z.string(),
    price: z.number()
  }))
});

type ProductFormData = z.infer<typeof productSchema>;

interface ProductFormProps {
  initialData?: ProductFormData;
  onSubmit: (data: ProductFormData) => Promise<void>;
  onCancel: () => void;
}

const ProductForm: React.FC<ProductFormProps> = ({
  initialData,
  onSubmit,
  onCancel
}) => {
  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
    setValue,
    watch
  } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: initialData || {
      name: '',
      description: '',
      price: 0,
      promo_price: null,
      image: '',
      category_id: '',
      is_active: true,
      is_featured: false,
      is_popular: false,
      ingredients: [''],
      options: [{ name: '', price: 0 }]
    }
  });

  const {
    fields: ingredientFields,
    append: appendIngredient,
    remove: removeIngredient
  } = useFieldArray({
    control,
    name: 'ingredients'
  });

  const {
    fields: optionFields,
    append: appendOption,
    remove: removeOption
  } = useFieldArray({
    control,
    name: 'options'
  });

  const addIngredient = () => {
    appendIngredient('');
  };

  const addOption = () => {
    appendOption({ name: '', price: 0 });
  };

  const handleFormSubmit = async (data: ProductFormData) => {
    try {
      await onSubmit(data);
      toast.success(initialData ? 'Produto atualizado!' : 'Produto criado!');
    } catch (error) {
      toast.error('Erro ao salvar produto');
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Nome</label>
          <input
            type="text"
            {...register('name')}
            className="input mt-1"
          />
          {errors.name && (
            <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Categoria</label>
          <select
            {...register('category_id')}
            className="input mt-1"
          >
            <option value="">Selecione uma categoria</option>
            <option value="pizza">Pizza</option>
            <option value="lanche">Lanche</option>
            <option value="bebida">Bebida</option>
            <option value="sobremesa">Sobremesa</option>
          </select>
          {errors.category_id && (
            <p className="text-red-500 text-sm mt-1">{errors.category_id.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Descrição</label>
        <textarea
          {...register('description')}
          rows={3}
          className="input mt-1"
        />
        {errors.description && (
          <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Preço</label>
          <input
            type="number"
            step="0.01"
            {...register('price', { valueAsNumber: true })}
            className="input mt-1"
          />
          {errors.price && (
            <p className="text-red-500 text-sm mt-1">{errors.price.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Preço Promocional (opcional)
          </label>
          <input
            type="number"
            step="0.01"
            {...register('promo_price', { valueAsNumber: true })}
            className="input mt-1"
          />
          {errors.promo_price && (
            <p className="text-red-500 text-sm mt-1">{errors.promo_price.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">URL da Imagem</label>
        <input
          type="url"
          {...register('image')}
          className="input mt-1"
        />
        {errors.image && (
          <p className="text-red-500 text-sm mt-1">{errors.image.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <div className="flex items-center">
          <input
            type="checkbox"
            {...register('is_active')}
            className="h-4 w-4 text-primary rounded border-gray-300"
          />
          <label className="ml-2 text-sm text-gray-700">Ativo</label>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            {...register('is_featured')}
            className="h-4 w-4 text-primary rounded border-gray-300"
          />
          <label className="ml-2 text-sm text-gray-700">Destaque</label>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            {...register('is_popular')}
            className="h-4 w-4 text-primary rounded border-gray-300"
          />
          <label className="ml-2 text-sm text-gray-700">Popular</label>
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-2">
          <label className="block text-sm font-medium text-gray-700">Ingredientes</label>
          <button
            type="button"
            onClick={addIngredient}
            className="text-primary hover:text-primary-dark"
          >
            <Plus size={20} />
          </button>
        </div>
        {ingredientFields.map((field, index) => (
          <div key={field.id} className="flex gap-2 mb-2">
            <input
              {...register(`ingredients.${index}`)}
              className="input flex-1"
              placeholder="Nome do ingrediente"
            />
            <button
              type="button"
              onClick={() => removeIngredient(index)}
              className="text-gray-400 hover:text-red-500"
              disabled={ingredientFields.length === 1}
            >
              <X size={20} />
            </button>
          </div>
        ))}
      </div>

      <div>
        <div className="flex justify-between items-center mb-2">
          <label className="block text-sm font-medium text-gray-700">Opções</label>
          <button
            type="button"
            onClick={addOption}
            className="text-primary hover:text-primary-dark"
          >
            <Plus size={20} />
          </button>
        </div>
        {optionFields.map((field, index) => (
          <div key={field.id} className="flex gap-2 mb-2">
            <input
              {...register(`options.${index}.name`)}
              className="input flex-1"
              placeholder="Nome da opção"
            />
            <input
              type="number"
              step="0.01"
              {...register(`options.${index}.price`, { valueAsNumber: true })}
              className="input w-32"
              placeholder="Preço"
            />
            <button
              type="button"
              onClick={() => removeOption(index)}
              className="text-gray-400 hover:text-red-500"
              disabled={optionFields.length === 1}
            >
              <X size={20} />
            </button>
          </div>
        ))}
      </div>

      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={onCancel}
          className="btn btn-outline"
        >
          Cancelar
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="btn btn-primary"
        >
          {isSubmitting ? 'Salvando...' : initialData ? 'Atualizar' : 'Criar'}
        </button>
      </div>
    </form>
  );
};

export default ProductForm;