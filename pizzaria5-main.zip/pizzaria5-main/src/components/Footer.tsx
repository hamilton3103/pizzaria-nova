import React from 'react';
import { Phone, MapPin, Clock, Instagram, Facebook } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-900 text-white pt-12 pb-6">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Phone size={20} className="mr-2 text-primary mt-1" />
                <div>
                  <p className="font-medium">Telefone:</p>
                  <p>(14) 99738-3236</p>
                </div>
              </li>
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 text-primary mt-1" />
                <div>
                  <p className="font-medium">Endereço:</p>
                  <p>Rua das Pizzas, 123</p>
                  <p>Centro - São Paulo, SP</p>
                </div>
              </li>
              <li className="flex items-start">
                <Clock size={20} className="mr-2 text-primary mt-1" />
                <div>
                  <p className="font-medium">Horário de Funcionamento:</p>
                  <p>Terça a Domingo: 18h às 23h</p>
                  <p>Segunda: Fechado</p>
                </div>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="hover:text-primary transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/menu/promocao" className="hover:text-primary transition-colors">
                  Promoções
                </Link>
              </li>
              <li>
                <Link to="/menu/pizza" className="hover:text-primary transition-colors">
                  Pizzas
                </Link>
              </li>
              <li>
                <Link to="/menu/lanche" className="hover:text-primary transition-colors">
                  Lanches
                </Link>
              </li>
              <li>
                <Link to="/menu/bebida" className="hover:text-primary transition-colors">
                  Bebidas
                </Link>
              </li>
              <li>
                <Link to="/menu/sobremesa" className="hover:text-primary transition-colors">
                  Sobremesas
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="mb-4">
              Inscreva-se para receber nossas promoções e novidades:
            </p>
            <form className="mb-4">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Seu e-mail"
                  className="px-3 py-2 rounded-l-md text-neutral-900 flex-1 focus:outline-none"
                />
                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark px-4 py-2 rounded-r-md transition-colors"
                >
                  Enviar
                </button>
              </div>
            </form>
            <div className="flex space-x-4">
              <a
                href="https://www.instagram.com/laricas.pizzaria/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition-colors"
              >
                <Instagram size={24} />
              </a>
              <a
                href="https://www.facebook.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition-colors"
              >
                <Facebook size={24} />
              </a>
            </div>
          </div>
        </div>
        
        {/* Bottom Section */}
        <div className="border-t border-neutral-800 pt-6 text-center text-neutral-400 text-sm">
          <p>
            &copy; {new Date().getFullYear()} Laricas Pizzaria. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;