import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Settings } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

const HeaderActionButtons: React.FC = () => {
  const { items } = useCart();
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  
  return (
    <div className="flex items-center space-x-4">
      {/* Cart Icon */}
      <Link
        to="/cart"
        className="text-gray-700 hover:text-primary transition-colors relative"
      >
        <ShoppingCart size={24} />
        {totalItems > 0 && (
          <span className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
            {totalItems}
          </span>
        )}
      </Link>

      {/* User Icon */}
      {isAuthenticated ? (
        <div className="relative group">
          <button className="text-gray-700 hover:text-primary transition-colors flex items-center space-x-2">
            <div className="h-8 w-8 bg-primary rounded-full flex items-center justify-center text-sm font-medium text-white">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <span className="hidden md:block text-sm font-medium">{user?.name}</span>
          </button>
          
          {/* Dropdown Menu */}
          <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg py-1 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border border-gray-200">
            <div className="px-4 py-3 border-b border-gray-100">
              <div className="font-medium text-gray-900">{user?.name || 'Usuário'}</div>
              <div className="text-sm text-gray-500">{user?.email || ''}</div>
              {isAdmin && (
                <span className="inline-block mt-1 px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                  Administrador
                </span>
              )}
            </div>
            
            {isAdmin && (
              <Link
                to="/admin"
                className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
              >
                <Settings size={16} className="mr-2" />
                Painel Admin
              </Link>
            )}
            
            <Link
              to="/profile"
              className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
            >
              <User size={16} className="mr-2" />
              Meu Perfil
            </Link>
            
            <Link
              to="/orders"
              className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
            >
              <ShoppingCart size={16} className="mr-2" />
              Meus Pedidos
            </Link>
            
            <button
              onClick={logout}
              className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
            >
              Sair
            </button>
          </div>
        </div>
      ) : (
        <Link
          to="/login"
          className="text-gray-700 hover:text-primary transition-colors flex items-center space-x-2"
        >
          <User size={24} />
          <span className="hidden md:block text-sm font-medium">Entrar</span>
        </Link>
      )}
    </div>
  );
};

export default HeaderActionButtons;