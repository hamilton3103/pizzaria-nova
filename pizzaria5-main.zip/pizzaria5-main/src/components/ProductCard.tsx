import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Plus } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface ProductCardProps {
  product: any;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };
  
  return (
    <Link to={`/product/${product.id}`} className="product-card animate-fade-in">
      <div className="relative overflow-hidden">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-48 object-cover transform transition-transform duration-300 hover:scale-105"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=600';
          }}
        />
        
        {product.promo_price && (
          <div className="absolute top-2 left-2 bg-accent text-white text-xs font-bold px-2 py-1 rounded-md">
            Promoção
          </div>
        )}
        
        {product.is_popular && (
          <div className="absolute top-2 right-2 bg-warning text-white text-xs font-bold px-2 py-1 rounded-md">
            Mais Vendido
          </div>
        )}
        
        <button
          onClick={handleAddToCart}
          className="absolute bottom-2 right-2 bg-primary hover:bg-primary-dark text-white p-2 rounded-full shadow-md transition-colors"
        >
          <ShoppingCart size={18} />
        </button>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-lg">{product.name}</h3>
          <span className={`category-badge badge-${product.categories?.slug || 'default'}`}>
            {product.categories?.name || 'Produto'}
          </span>
        </div>
        
        <p className="text-neutral-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>
        
        <div className="flex justify-between items-center">
          <div>
            {product.promo_price ? (
              <div className="flex items-center">
                <span className="text-neutral-500 line-through text-sm mr-2">
                  {formatPrice(product.price)}
                </span>
                <span className="text-primary font-bold">
                  {formatPrice(product.promo_price)}
                </span>
              </div>
            ) : (
              <span className="font-bold">{formatPrice(product.price)}</span>
            )}
          </div>
          
          <button
            onClick={handleAddToCart}
            className="text-primary hover:text-primary-dark"
          >
            <Plus size={20} />
          </button>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;