import React, { useState, useEffect } from 'react';
import { Instagram } from 'lucide-react';

const mockInstagramPosts = [
  {
    id: '1',
    permalink: 'https://www.instagram.com/p/1/',
    media_url: 'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg?auto=compress&cs=tinysrgb&w=600',
    caption: 'Nossa pizza de calabresa está incrível! Peça já a sua! 🍕 #pizza #calabresa #laricaspizzaria',
    timestamp: '2023-05-15T18:30:00Z',
  },
  {
    id: '2',
    permalink: 'https://www.instagram.com/p/2/',
    media_url: 'https://images.pexels.com/photos/905847/pexels-photo-905847.jpeg?auto=compress&cs=tinysrgb&w=600',
    caption: 'Olha que maravilha nossa pizza de frango com catupiry! 😋 #pizza #frango #catupiry #delivery',
    timestamp: '2023-05-10T19:15:00Z',
  },
  {
    id: '3',
    permalink: 'https://www.instagram.com/p/3/',
    media_url: 'https://images.pexels.com/photos/2619970/pexels-photo-2619970.jpeg?auto=compress&cs=tinysrgb&w=600',
    caption: 'Hamburgueres suculentos com batata frita crocante! Peça já o seu! 🍔 #hamburguer #lanche #delivery',
    timestamp: '2023-05-05T20:00:00Z',
  },
  {
    id: '4',
    permalink: 'https://www.instagram.com/p/4/',
    media_url: 'https://images.pexels.com/photos/1566837/pexels-photo-1566837.jpeg?auto=compress&cs=tinysrgb&w=600',
    caption: 'Temos bebidas geladas para acompanhar seu pedido! 🥤 #refrigerante #bebidas #delivery',
    timestamp: '2023-04-30T17:45:00Z',
  }
];

const InstagramFeed: React.FC = () => {
  const [posts, setPosts] = useState(mockInstagramPosts);
  const [loading, setLoading] = useState(false);

  // In a real application, you would fetch the Instagram posts here
  useEffect(() => {
    // Simulating API call
    setLoading(true);
    setTimeout(() => {
      setPosts(mockInstagramPosts);
      setLoading(false);
    }, 500);
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="py-8">
      <div className="container mx-auto">
        <div className="flex items-center justify-center mb-6">
          <Instagram size={24} className="text-primary mr-2" />
          <h2 className="text-2xl font-bold">Siga-nos no Instagram</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {posts.map((post) => (
            <a
              key={post.id}
              href={post.permalink}
              target="_blank"
              rel="noopener noreferrer"
              className="block overflow-hidden rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="relative group">
                <img
                  src={post.media_url}
                  alt="Instagram post"
                  className="w-full h-64 object-cover transform transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 flex items-center justify-center transition-all duration-300 opacity-0 group-hover:opacity-100">
                  <Instagram size={32} className="text-white" />
                </div>
              </div>
            </a>
          ))}
        </div>
        
        <div className="flex justify-center mt-6">
          <a
            href="https://www.instagram.com/laricas.pizzaria/"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-outline"
          >
            Ver mais no Instagram
          </a>
        </div>
      </div>
    </div>
  );
};

export default InstagramFeed;