import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Search, Instagram } from 'lucide-react';
import HeaderActionButtons from './HeaderActionButtons';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white shadow-md py-2'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img 
            src="https://laricas.com.br/images/logo-laricas.png" 
            alt="Laricas Pizzaria"
            className="h-12 w-auto"
          />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-6">
          <Link
            to="/menu/promocao"
            className="font-medium hover:text-primary transition-colors"
          >
            Promoções
          </Link>
          <Link
            to="/menu/pizza"
            className="font-medium hover:text-primary transition-colors"
          >
            Pizzas
          </Link>
          <Link
            to="/menu/lanche"
            className="font-medium hover:text-primary transition-colors"
          >
            Lanches
          </Link>
          <Link
            to="/menu/bebida"
            className="font-medium hover:text-primary transition-colors"
          >
            Bebidas
          </Link>
          <Link
            to="/menu/sobremesa"
            className="font-medium hover:text-primary transition-colors"
          >
            Sobremesas
          </Link>
        </nav>

        {/* Right side icons */}
        <div className="flex items-center space-x-4">
          <form onSubmit={handleSearch} className="hidden md:flex items-center">
            <input
              type="text"
              placeholder="Buscar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3 py-1 rounded-l-md border border-gray-300 focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button
              type="submit"
              className="bg-primary text-white p-1 rounded-r-md hover:bg-primary-dark transition-colors"
            >
              <Search size={20} />
            </button>
          </form>

          <a
            href="https://www.instagram.com/laricas.pizzaria/"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:block text-neutral-700 hover:text-primary transition-colors"
          >
            <Instagram size={24} />
          </a>

          <HeaderActionButtons />

          <button
            onClick={toggleMenu}
            className="text-neutral-700 md:hidden"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg animate-fade-in">
          <div className="container mx-auto py-4">
            <form onSubmit={handleSearch} className="mb-4 flex">
              <input
                type="text"
                placeholder="Buscar..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 px-3 py-2 rounded-l-md border border-gray-300 focus:outline-none"
              />
              <button
                type="submit"
                className="bg-primary text-white p-2 rounded-r-md"
              >
                <Search size={20} />
              </button>
            </form>

            <nav className="flex flex-col space-y-3">
              <Link
                to="/menu/promocao"
                className="font-medium py-2 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Promoções
              </Link>
              <Link
                to="/menu/pizza"
                className="font-medium py-2 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Pizzas
              </Link>
              <Link
                to="/menu/lanche"
                className="font-medium py-2 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Lanches
              </Link>
              <Link
                to="/menu/bebida"
                className="font-medium py-2 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Bebidas
              </Link>
              <Link
                to="/menu/sobremesa"
                className="font-medium py-2 hover:text-primary transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobremesas
              </Link>
              
              <div className="border-t border-gray-200 pt-3">
                <a
                  href="https://www.instagram.com/laricas.pizzaria/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center py-2 hover:text-primary transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Instagram size={20} className="mr-2" />
                  Instagram
                </a>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;