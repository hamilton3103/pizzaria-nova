import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';

const FloatingCart: React.FC = () => {
  const { items, total } = useCart();
  
  if (items.length === 0) return null;
  
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  
  return (
    <div className="fixed bottom-4 right-4 md:bottom-8 md:right-8 z-40">
      <Link
        to="/cart"
        className="flex items-center bg-primary hover:bg-primary-dark text-white p-3 rounded-full shadow-lg transition-all transform hover:scale-105"
      >
        <ShoppingCart size={24} />
        <span className="ml-2 font-medium">{totalItems}</span>
        <span className="ml-2 hidden md:inline">
          {new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL',
          }).format(total)}
        </span>
      </Link>
    </div>
  );
};

export default FloatingCart;