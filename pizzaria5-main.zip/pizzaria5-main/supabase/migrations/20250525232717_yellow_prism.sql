/*
  # Database Schema Setup
  
  1. Tables
    - Users and authentication
    - Products and categories
    - Orders and order items
    - Addresses
  
  2. Security
    - Row Level Security (RLS) enabled on all tables
    - Policies for data access control
    
  3. Default Data
    - Product categories
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Users can delete own data" ON users;
DROP POLICY IF EXISTS "Enable insert for registration" ON users;
DROP POLICY IF EXISTS "Users can manage own addresses" ON addresses;
DROP POLICY IF EXISTS "Anyone can read categories" ON categories;
DROP POLICY IF EXISTS "Anyone can read products" ON products;
DROP POLICY IF EXISTS "Anyone can read product options" ON product_options;
DROP POLICY IF EXISTS "Anyone can read product ingredients" ON product_ingredients;
DROP POLICY IF EXISTS "Users can read their own orders" ON orders;
DROP POLICY IF EXISTS "Users can read their own order items" ON order_items;
DROP POLICY IF EXISTS "Users can read their own order item options" ON order_item_options;

-- Create tables if they don't exist
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name varchar(100) NOT NULL,
  email varchar(100) NOT NULL UNIQUE,
  password varchar(255) NOT NULL,
  phone varchar(20),
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS addresses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  street varchar(255) NOT NULL,
  number varchar(20) NOT NULL,
  complement varchar(100),
  neighborhood varchar(100) NOT NULL,
  city varchar(100) NOT NULL,
  state varchar(2) NOT NULL,
  zip_code varchar(10) NOT NULL,
  is_default boolean DEFAULT false
);

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name varchar(50) NOT NULL,
  slug varchar(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name varchar(100) NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  promo_price decimal(10,2),
  image varchar(255),
  category_id uuid NOT NULL REFERENCES categories(id),
  is_active boolean DEFAULT true,
  is_featured boolean DEFAULT false,
  is_popular boolean DEFAULT false,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_options (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL,
  price decimal(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS product_ingredients (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id),
  address_id uuid NOT NULL REFERENCES addresses(id),
  status varchar(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
  payment_method varchar(20) NOT NULL
    CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
  subtotal decimal(10,2) NOT NULL,
  delivery_fee decimal(10,2) NOT NULL,
  total decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  notes text
);

CREATE TABLE IF NOT EXISTS order_item_options (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_item_id uuid NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  product_option_id uuid NOT NULL REFERENCES product_options(id),
  price decimal(10,2) NOT NULL
);

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_item_options ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own data"
  ON users FOR SELECT
  TO public
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users FOR UPDATE
  TO public
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can delete own data"
  ON users FOR DELETE
  TO public
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for registration"
  ON users FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can manage own addresses"
  ON addresses FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Anyone can read categories"
  ON categories FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read products"
  ON products FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read product options"
  ON product_options FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read product ingredients"
  ON product_ingredients FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Users can read their own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can read their own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders
    WHERE orders.id = order_items.order_id
    AND orders.user_id = auth.uid()
  ));

CREATE POLICY "Users can read their own order item options"
  ON order_item_options FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM order_items
    JOIN orders ON orders.id = order_items.order_id
    WHERE order_items.id = order_item_options.order_item_id
    AND orders.user_id = auth.uid()
  ));

-- Insert default categories if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'pizza') THEN
    INSERT INTO categories (name, slug) VALUES ('Pizza', 'pizza');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'lanche') THEN
    INSERT INTO categories (name, slug) VALUES ('Lanche', 'lanche');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'bebida') THEN
    INSERT INTO categories (name, slug) VALUES ('Bebida', 'bebida');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'promocao') THEN
    INSERT INTO categories (name, slug) VALUES ('Promoção', 'promocao');
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'sobremesa') THEN
    INSERT INTO categories (name, slug) VALUES ('Sobremesa', 'sobremesa');
  END IF;
END $$;