/*
  # Add UUID extension
  
  1. Changes
    - Creates the uuid-ossp extension if it doesn't exist
*/

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" SCHEMA extensions;

-- Grant usage to authenticated and anon roles
GRANT USAGE ON SCHEMA extensions TO authenticated, anon;