-- Correção DEFINITIVA de permissões MySQL
-- Execute este script como ROOT ou administrador do MySQL

-- 1. Criar o banco de dados se não existir
CREATE DATABASE IF NOT EXISTS laricas_bdados 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- 2. Usar o banco de dados
USE laricas_bdados;

-- 3. Criar usuário com as credenciais corretas
-- Remover usuário se existir
DROP USER IF EXISTS 'laricas_bdados'@'%';
DROP USER IF EXISTS 'laricas_bdados'@'localhost';
DROP USER IF EXISTS 'laricas_bdados'@'192.185.176.242';

-- Criar usuário com senha correta
CREATE USER 'laricas_bdados'@'%' IDENTIFIED BY 'Ha31038866##';
CREATE USER 'laricas_bdados'@'localhost' IDENTIFIED BY 'Ha31038866##';
CREATE USER 'laricas_bdados'@'192.185.176.242' IDENTIFIED BY 'Ha31038866##';

-- 4. Conceder TODAS as permissões no banco laricas_bdados
GRANT ALL PRIVILEGES ON laricas_bdados.* TO 'laricas_bdados'@'%';
GRANT ALL PRIVILEGES ON laricas_bdados.* TO 'laricas_bdados'@'localhost';
GRANT ALL PRIVILEGES ON laricas_bdados.* TO 'laricas_bdados'@'192.185.176.242';

-- 5. Conceder permissões globais necessárias
GRANT CREATE, DROP, ALTER, INDEX ON *.* TO 'laricas_bdados'@'%';
GRANT CREATE, DROP, ALTER, INDEX ON *.* TO 'laricas_bdados'@'localhost';
GRANT CREATE, DROP, ALTER, INDEX ON *.* TO 'laricas_bdados'@'192.185.176.242';

-- 6. Aplicar mudanças
FLUSH PRIVILEGES;

-- 7. Verificar permissões
SHOW GRANTS FOR 'laricas_bdados'@'%';
SHOW GRANTS FOR 'laricas_bdados'@'localhost';

-- 8. Testar conexão
SELECT 'Permissões configuradas com sucesso!' as status;