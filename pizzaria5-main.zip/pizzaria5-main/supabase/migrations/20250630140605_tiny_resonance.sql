/*
  # Setup Authentication and Database Schema

  1. New Tables
    - `users` - User profiles (extends auth.users)
    - `categories` - Product categories
    - `products` - Menu items
    - `product_options` - Product variations
    - `product_ingredients` - Product ingredients
    - `addresses` - User delivery addresses
    - `orders` - Customer orders
    - `order_items` - Items in orders
    - `order_item_options` - Selected options for order items

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Public read access for products and categories

  3. Functions
    - Custom function to handle user registration
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom users table (extends auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  role text DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Products table
CREATE TABLE IF NOT EXISTS public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  promo_price decimal(10,2),
  image text,
  category_id uuid REFERENCES public.categories(id) NOT NULL,
  is_active boolean DEFAULT true,
  is_featured boolean DEFAULT false,
  is_popular boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Product options table
CREATE TABLE IF NOT EXISTS public.product_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  price decimal(10,2) DEFAULT 0
);

ALTER TABLE public.product_options ENABLE ROW LEVEL SECURITY;

-- Product ingredients table
CREATE TABLE IF NOT EXISTS public.product_ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL
);

ALTER TABLE public.product_ingredients ENABLE ROW LEVEL SECURITY;

-- Addresses table
CREATE TABLE IF NOT EXISTS public.addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  street text NOT NULL,
  number text NOT NULL,
  complement text,
  neighborhood text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  zip_code text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;

-- Orders table
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id) NOT NULL,
  address_id uuid REFERENCES public.addresses(id) NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
  payment_method text NOT NULL CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
  subtotal decimal(10,2) NOT NULL,
  delivery_fee decimal(10,2) NOT NULL,
  total decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Order items table
CREATE TABLE IF NOT EXISTS public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES public.orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES public.products(id) NOT NULL,
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  notes text
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Order item options table
CREATE TABLE IF NOT EXISTS public.order_item_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id uuid REFERENCES public.order_items(id) ON DELETE CASCADE NOT NULL,
  product_option_id uuid REFERENCES public.product_options(id) NOT NULL,
  price decimal(10,2) NOT NULL
);

ALTER TABLE public.order_item_options ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Users policies
CREATE POLICY "Users can read own data" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON public.users
  FOR UPDATE USING (auth.uid() = id);

-- Categories policies (public read)
CREATE POLICY "Anyone can read categories" ON public.categories
  FOR SELECT TO anon, authenticated USING (true);

-- Products policies (public read)
CREATE POLICY "Anyone can read products" ON public.products
  FOR SELECT TO anon, authenticated USING (true);

-- Product options policies (public read)
CREATE POLICY "Anyone can read product options" ON public.product_options
  FOR SELECT TO anon, authenticated USING (true);

-- Product ingredients policies (public read)
CREATE POLICY "Anyone can read product ingredients" ON public.product_ingredients
  FOR SELECT TO anon, authenticated USING (true);

-- Addresses policies
CREATE POLICY "Users can manage own addresses" ON public.addresses
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Orders policies
CREATE POLICY "Users can read own orders" ON public.orders
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Order items policies
CREATE POLICY "Users can read own order items" ON public.order_items
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Order item options policies
CREATE POLICY "Users can read own order item options" ON public.order_item_options
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.order_items
      JOIN public.orders ON orders.id = order_items.order_id
      WHERE order_items.id = order_item_options.order_item_id
      AND orders.user_id = auth.uid()
    )
  );

-- Function to handle user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.users (id, name, email, role)
  VALUES (
    new.id,
    COALESCE(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    CASE 
      WHEN new.email = 'admin@laricas.com' THEN 'admin'
      ELSE 'user'
    END
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Insert default categories
INSERT INTO public.categories (name, slug) VALUES
  ('Pizza', 'pizza'),
  ('Lanche', 'lanche'),
  ('Bebida', 'bebida'),
  ('Promoção', 'promocao'),
  ('Sobremesa', 'sobremesa')
ON CONFLICT (slug) DO NOTHING;

-- Insert sample products
INSERT INTO public.products (name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) 
SELECT 
  'Pizza Margherita',
  'Pizza clássica com molho de tomate, mussarela e manjericão fresco',
  35.90,
  NULL,
  'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg',
  c.id,
  true,
  true,
  false
FROM public.categories c WHERE c.slug = 'pizza'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) 
SELECT 
  'Pizza Pepperoni',
  'Pizza com molho de tomate, mussarela e pepperoni',
  42.90,
  38.90,
  'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg',
  c.id,
  true,
  false,
  true
FROM public.categories c WHERE c.slug = 'pizza'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) 
SELECT 
  'X-Burger Clássico',
  'Hambúrguer artesanal com queijo, alface, tomate e molho especial',
  28.90,
  NULL,
  'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg',
  c.id,
  true,
  false,
  true
FROM public.categories c WHERE c.slug = 'lanche'
ON CONFLICT DO NOTHING;

INSERT INTO public.products (name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) 
SELECT 
  'Coca-Cola 350ml',
  'Refrigerante Coca-Cola gelado',
  6.90,
  NULL,
  'https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg',
  c.id,
  true,
  false,
  false
FROM public.categories c WHERE c.slug = 'bebida'
ON CONFLICT DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_featured ON public.products(is_featured);
CREATE INDEX IF NOT EXISTS idx_products_popular ON public.products(is_popular);
CREATE INDEX IF NOT EXISTS idx_orders_user ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON public.order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON public.addresses(user_id);