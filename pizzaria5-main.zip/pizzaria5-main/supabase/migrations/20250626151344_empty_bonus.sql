-- Correção de permissões para o banco laricas_bdados
-- Execute este script como administrador do MySQL

-- Criar o banco de dados se não existir
CREATE DATABASE IF NOT EXISTS laricas_bdados;

-- Usar o banco de dados
USE laricas_bdados;

-- Criar usuário se não existir (substitua pela senha correta)
CREATE USER IF NOT EXISTS 'laricas_bdados'@'%' IDENTIFIED BY 'Ha31038866##';
CREATE USER IF NOT EXISTS 'laricas_bdados'@'localhost' IDENTIFIED BY 'Ha31038866##';

-- Conceder todas as permissões no banco laricas_bdados
GRANT ALL PRIVILEGES ON laricas_bdados.* TO 'laricas_bdados'@'%';
GRANT ALL PRIVILEGES ON laricas_bdados.* TO 'laricas_bdados'@'localhost';

-- Aplicar as mudanças
FLUSH PRIVILEGES;

-- Verificar se o usuário tem acesso
SHOW GRANTS FOR 'laricas_bdados'@'%';
SHOW GRANTS FOR 'laricas_bdados'@'localhost';