/*
  # Database Schema Update
  
  1. Tables
    - Checks for existing tables before creation
    - Creates tables if they don't exist:
      - users
      - addresses
      - categories
      - products
      - product_options
      - product_ingredients
      - orders
      - order_items
      - order_item_options
  
  2. Security
    - Enables RLS on all tables
    - Sets up appropriate access policies
    
  3. Data
    - Inserts default categories if they don't exist
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create tables only if they don't exist
DO $$ 
BEGIN
  -- Users table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'users') THEN
    CREATE TABLE users (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      name varchar(100) NOT NULL,
      email varchar(100) NOT NULL UNIQUE,
      password varchar(255) NOT NULL,
      phone varchar(20),
      created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
    );

    ALTER TABLE users ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Users can read own data"
      ON users FOR SELECT TO public
      USING (auth.uid() = id);

    CREATE POLICY "Users can update own data"
      ON users FOR UPDATE TO public
      USING (auth.uid() = id)
      WITH CHECK (auth.uid() = id);

    CREATE POLICY "Users can delete own data"
      ON users FOR DELETE TO public
      USING (auth.uid() = id);

    CREATE POLICY "Enable insert for registration"
      ON users FOR INSERT TO public
      WITH CHECK (true);
  END IF;

  -- Addresses table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'addresses') THEN
    CREATE TABLE addresses (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      street varchar(255) NOT NULL,
      number varchar(20) NOT NULL,
      complement varchar(100),
      neighborhood varchar(100) NOT NULL,
      city varchar(100) NOT NULL,
      state varchar(2) NOT NULL,
      zip_code varchar(10) NOT NULL,
      is_default boolean DEFAULT false
    );

    ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Users can manage own addresses"
      ON addresses FOR ALL TO authenticated
      USING (auth.uid() = user_id)
      WITH CHECK (auth.uid() = user_id);
  END IF;

  -- Categories table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'categories') THEN
    CREATE TABLE categories (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      name varchar(50) NOT NULL,
      slug varchar(50) NOT NULL UNIQUE
    );

    ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read categories"
      ON categories FOR SELECT TO anon, authenticated
      USING (true);

    -- Insert default categories
    INSERT INTO categories (name, slug) VALUES
      ('Pizza', 'pizza'),
      ('Lanche', 'lanche'),
      ('Bebida', 'bebida'),
      ('Promoção', 'promocao'),
      ('Sobremesa', 'sobremesa');
  END IF;

  -- Products table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'products') THEN
    CREATE TABLE products (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      name varchar(100) NOT NULL,
      description text,
      price decimal(10,2) NOT NULL,
      promo_price decimal(10,2),
      image varchar(255),
      category_id uuid NOT NULL REFERENCES categories(id),
      is_active boolean DEFAULT true,
      is_featured boolean DEFAULT false,
      is_popular boolean DEFAULT false,
      created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
    );

    ALTER TABLE products ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read products"
      ON products FOR SELECT TO anon, authenticated
      USING (true);
  END IF;

  -- Product options table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'product_options') THEN
    CREATE TABLE product_options (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      name varchar(100) NOT NULL,
      price decimal(10,2) NOT NULL DEFAULT 0
    );

    ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read product options"
      ON product_options FOR SELECT TO anon, authenticated
      USING (true);
  END IF;

  -- Product ingredients table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'product_ingredients') THEN
    CREATE TABLE product_ingredients (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      name varchar(100) NOT NULL
    );

    ALTER TABLE product_ingredients ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read product ingredients"
      ON product_ingredients FOR SELECT TO anon, authenticated
      USING (true);
  END IF;

  -- Orders table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'orders') THEN
    CREATE TABLE orders (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id uuid NOT NULL REFERENCES users(id),
      address_id uuid NOT NULL REFERENCES addresses(id),
      status varchar(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
      payment_method varchar(20) NOT NULL
        CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
      subtotal decimal(10,2) NOT NULL,
      delivery_fee decimal(10,2) NOT NULL,
      total decimal(10,2) NOT NULL,
      created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
    );

    ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Users can read their own orders"
      ON orders FOR SELECT TO authenticated
      USING (auth.uid() = user_id);
  END IF;

  -- Order items table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'order_items') THEN
    CREATE TABLE order_items (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      product_id uuid NOT NULL REFERENCES products(id),
      quantity integer NOT NULL,
      unit_price decimal(10,2) NOT NULL,
      notes text
    );

    ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Users can read their own order items"
      ON order_items FOR SELECT TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_items.order_id
        AND orders.user_id = auth.uid()
      ));
  END IF;

  -- Order item options table
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'order_item_options') THEN
    CREATE TABLE order_item_options (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      order_item_id uuid NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
      product_option_id uuid NOT NULL REFERENCES product_options(id),
      price decimal(10,2) NOT NULL
    );

    ALTER TABLE order_item_options ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Users can read their own order item options"
      ON order_item_options FOR SELECT TO authenticated
      USING (EXISTS (
        SELECT 1 FROM order_items
        JOIN orders ON orders.id = order_items.order_id
        WHERE order_items.id = order_item_options.order_item_id
        AND orders.user_id = auth.uid()
      ));
  END IF;
END $$;