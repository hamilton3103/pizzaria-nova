-- Database schema for Laricas Pizzaria Admin Panel
-- MySQL Database: laricas_bdados

USE laricas_bdados;

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Users table (includes both admin and regular users)
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  role ENUM('admin', 'user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role)
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  slug VARCHAR(50) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug)
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  promo_price DECIMAL(10,2),
  image VARCHAR(255),
  category_id VARCHAR(50) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_featured BOOLEAN DEFAULT FALSE,
  is_popular BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_category (category_id),
  INDEX idx_active (is_active),
  INDEX idx_featured (is_featured),
  INDEX idx_popular (is_popular),
  INDEX idx_name (name)
);

-- Product options table
CREATE TABLE IF NOT EXISTS product_options (
  id VARCHAR(50) PRIMARY KEY,
  product_id VARCHAR(50) NOT NULL,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_product (product_id)
);

-- Product ingredients table
CREATE TABLE IF NOT EXISTS product_ingredients (
  id VARCHAR(50) PRIMARY KEY,
  product_id VARCHAR(50) NOT NULL,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_product (product_id)
);

-- Addresses table
CREATE TABLE IF NOT EXISTS addresses (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  street VARCHAR(255) NOT NULL,
  number VARCHAR(20) NOT NULL,
  complement VARCHAR(100),
  neighborhood VARCHAR(100) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(2) NOT NULL,
  zip_code VARCHAR(10) NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  address_id VARCHAR(50) NOT NULL,
  status ENUM('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled') DEFAULT 'pending',
  payment_method ENUM('pix', 'credit_card', 'cash') NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (address_id) REFERENCES addresses(id),
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id VARCHAR(50) PRIMARY KEY,
  order_id VARCHAR(50) NOT NULL,
  product_id VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id),
  INDEX idx_order (order_id),
  INDEX idx_product (product_id)
);

-- Order item options table
CREATE TABLE IF NOT EXISTS order_item_options (
  id VARCHAR(50) PRIMARY KEY,
  order_item_id VARCHAR(50) NOT NULL,
  product_option_id VARCHAR(50) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE,
  FOREIGN KEY (product_option_id) REFERENCES product_options(id),
  INDEX idx_order_item (order_item_id)
);

-- Insert default categories
INSERT IGNORE INTO categories (id, name, slug) VALUES
('cat_pizza_001', 'Pizza', 'pizza'),
('cat_lanche_002', 'Lanche', 'lanche'),
('cat_bebida_003', 'Bebida', 'bebida'),
('cat_promocao_004', 'Promoção', 'promocao'),
('cat_sobremesa_005', 'Sobremesa', 'sobremesa');

-- Insert default admin user (password: admin123)
-- Hash: $2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
INSERT IGNORE INTO users (id, name, email, password, role) VALUES
('admin_001', 'Administrador', 'admin@laricas.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert sample products
INSERT IGNORE INTO products (id, name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) VALUES
('prod_pizza_001', 'Pizza Margherita', 'Pizza clássica com molho de tomate, mussarela e manjericão fresco', 35.90, NULL, 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg', 'cat_pizza_001', TRUE, TRUE, FALSE),
('prod_pizza_002', 'Pizza Pepperoni', 'Pizza com molho de tomate, mussarela e pepperoni', 42.90, 38.90, 'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg', 'cat_pizza_001', TRUE, FALSE, TRUE),
('prod_lanche_001', 'X-Burger Clássico', 'Hambúrguer artesanal com queijo, alface, tomate e molho especial', 28.90, NULL, 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg', 'cat_lanche_002', TRUE, FALSE, TRUE),
('prod_bebida_001', 'Coca-Cola 350ml', 'Refrigerante Coca-Cola gelado', 6.90, NULL, 'https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg', 'cat_bebida_003', TRUE, FALSE, FALSE);

-- Insert sample product options
INSERT IGNORE INTO product_options (id, product_id, name, price) VALUES
('opt_001', 'prod_pizza_001', 'Pequena', 0.00),
('opt_002', 'prod_pizza_001', 'Média', 5.00),
('opt_003', 'prod_pizza_001', 'Grande', 10.00),
('opt_004', 'prod_pizza_002', 'Pequena', 0.00),
('opt_005', 'prod_pizza_002', 'Média', 5.00),
('opt_006', 'prod_pizza_002', 'Grande', 10.00);

-- Insert sample product ingredients
INSERT IGNORE INTO product_ingredients (id, product_id, name) VALUES
('ing_001', 'prod_pizza_001', 'Molho de tomate'),
('ing_002', 'prod_pizza_001', 'Mussarela'),
('ing_003', 'prod_pizza_001', 'Manjericão'),
('ing_004', 'prod_pizza_002', 'Molho de tomate'),
('ing_005', 'prod_pizza_002', 'Mussarela'),
('ing_006', 'prod_pizza_002', 'Pepperoni'),
('ing_007', 'prod_lanche_001', 'Pão brioche'),
('ing_008', 'prod_lanche_001', 'Hambúrguer 180g'),
('ing_009', 'prod_lanche_001', 'Queijo'),
('ing_010', 'prod_lanche_001', 'Alface'),
('ing_011', 'prod_lanche_001', 'Tomate'),
('ing_012', 'prod_lanche_001', 'Molho especial');