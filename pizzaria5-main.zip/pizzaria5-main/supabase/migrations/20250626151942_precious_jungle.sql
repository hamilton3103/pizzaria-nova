-- Schema COMPLETO para Laricas Pizzaria Admin Panel
-- Execute APÓS corrigir as permissões

USE laricasp_bdados;

-- Configurações iniciais
SET FOREIGN_KEY_CHECKS = 1;
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO';

-- =====================================================
-- TABELAS PRINCIPAIS
-- =====================================================

-- Tabela de usuários (admin e clientes)
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  role ENUM('admin', 'user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  slug VARCHAR(50) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de produtos
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  promo_price DECIMAL(10,2) NULL,
  image VARCHAR(500),
  category_id VARCHAR(50) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_featured BOOLEAN DEFAULT FALSE,
  is_popular BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON UPDATE CASCADE,
  INDEX idx_category (category_id),
  INDEX idx_active (is_active),
  INDEX idx_featured (is_featured),
  INDEX idx_popular (is_popular),
  INDEX idx_name (name),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de opções de produtos
CREATE TABLE IF NOT EXISTS product_options (
  id VARCHAR(50) PRIMARY KEY,
  product_id VARCHAR(50) NOT NULL,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de ingredientes
CREATE TABLE IF NOT EXISTS product_ingredients (
  id VARCHAR(50) PRIMARY KEY,
  product_id VARCHAR(50) NOT NULL,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de endereços
CREATE TABLE IF NOT EXISTS addresses (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  street VARCHAR(255) NOT NULL,
  number VARCHAR(20) NOT NULL,
  complement VARCHAR(100),
  neighborhood VARCHAR(100) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(2) NOT NULL,
  zip_code VARCHAR(10) NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_default (is_default)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  address_id VARCHAR(50) NOT NULL,
  status ENUM('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled') DEFAULT 'pending',
  payment_method ENUM('pix', 'credit_card', 'cash') NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE,
  FOREIGN KEY (address_id) REFERENCES addresses(id) ON UPDATE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at),
  INDEX idx_payment_method (payment_method)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de itens do pedido
CREATE TABLE IF NOT EXISTS order_items (
  id VARCHAR(50) PRIMARY KEY,
  order_id VARCHAR(50) NOT NULL,
  product_id VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON UPDATE CASCADE,
  INDEX idx_order (order_id),
  INDEX idx_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de opções dos itens
CREATE TABLE IF NOT EXISTS order_item_options (
  id VARCHAR(50) PRIMARY KEY,
  order_item_id VARCHAR(50) NOT NULL,
  product_option_id VARCHAR(50) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (product_option_id) REFERENCES product_options(id) ON UPDATE CASCADE,
  INDEX idx_order_item (order_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- DADOS INICIAIS
-- =====================================================

-- Inserir categorias padrão
INSERT IGNORE INTO categories (id, name, slug) VALUES
('cat_pizza_001', 'Pizza', 'pizza'),
('cat_lanche_002', 'Lanche', 'lanche'),
('cat_bebida_003', 'Bebida', 'bebida'),
('cat_promocao_004', 'Promoção', 'promocao'),
('cat_sobremesa_005', 'Sobremesa', 'sobremesa');

-- Inserir usuário admin (senha: admin123)
INSERT IGNORE INTO users (id, name, email, password, role) VALUES
('admin_001', 'Administrador', 'admin@laricas.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Inserir produtos de demonstração
INSERT IGNORE INTO products (id, name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular) VALUES
('prod_pizza_001', 'Pizza Margherita', 'Pizza clássica com molho de tomate, mussarela e manjericão fresco', 35.90, NULL, 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg', 'cat_pizza_001', TRUE, TRUE, FALSE),
('prod_pizza_002', 'Pizza Pepperoni', 'Pizza com molho de tomate, mussarela e pepperoni', 42.90, 38.90, 'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg', 'cat_pizza_001', TRUE, FALSE, TRUE),
('prod_pizza_003', 'Pizza Calabresa', 'Pizza com molho de tomate, mussarela e calabresa', 39.90, NULL, 'https://images.pexels.com/photos/4109111/pexels-photo-4109111.jpeg', 'cat_pizza_001', TRUE, FALSE, TRUE),
('prod_lanche_001', 'X-Burger Clássico', 'Hambúrguer artesanal com queijo, alface, tomate e molho especial', 28.90, NULL, 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg', 'cat_lanche_002', TRUE, FALSE, TRUE),
('prod_lanche_002', 'X-Bacon', 'Hambúrguer com bacon, queijo, alface, tomate e molho especial', 32.90, 29.90, 'https://images.pexels.com/photos/2983101/pexels-photo-2983101.jpeg', 'cat_lanche_002', TRUE, TRUE, FALSE),
('prod_bebida_001', 'Coca-Cola 350ml', 'Refrigerante Coca-Cola gelado', 6.90, NULL, 'https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg', 'cat_bebida_003', TRUE, FALSE, FALSE),
('prod_bebida_002', 'Suco de Laranja 500ml', 'Suco natural de laranja', 8.90, NULL, 'https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg', 'cat_bebida_003', TRUE, FALSE, FALSE);

-- Inserir opções de produtos
INSERT IGNORE INTO product_options (id, product_id, name, price) VALUES
('opt_001', 'prod_pizza_001', 'Pequena', 0.00),
('opt_002', 'prod_pizza_001', 'Média', 5.00),
('opt_003', 'prod_pizza_001', 'Grande', 10.00),
('opt_004', 'prod_pizza_002', 'Pequena', 0.00),
('opt_005', 'prod_pizza_002', 'Média', 5.00),
('opt_006', 'prod_pizza_002', 'Grande', 10.00),
('opt_007', 'prod_pizza_003', 'Pequena', 0.00),
('opt_008', 'prod_pizza_003', 'Média', 5.00),
('opt_009', 'prod_pizza_003', 'Grande', 10.00),
('opt_010', 'prod_lanche_001', 'Simples', 0.00),
('opt_011', 'prod_lanche_001', 'Duplo', 8.00),
('opt_012', 'prod_lanche_002', 'Simples', 0.00),
('opt_013', 'prod_lanche_002', 'Duplo', 8.00);

-- Inserir ingredientes
INSERT IGNORE INTO product_ingredients (id, product_id, name) VALUES
('ing_001', 'prod_pizza_001', 'Molho de tomate'),
('ing_002', 'prod_pizza_001', 'Mussarela'),
('ing_003', 'prod_pizza_001', 'Manjericão'),
('ing_004', 'prod_pizza_002', 'Molho de tomate'),
('ing_005', 'prod_pizza_002', 'Mussarela'),
('ing_006', 'prod_pizza_002', 'Pepperoni'),
('ing_007', 'prod_pizza_003', 'Molho de tomate'),
('ing_008', 'prod_pizza_003', 'Mussarela'),
('ing_009', 'prod_pizza_003', 'Calabresa'),
('ing_010', 'prod_lanche_001', 'Pão brioche'),
('ing_011', 'prod_lanche_001', 'Hambúrguer 180g'),
('ing_012', 'prod_lanche_001', 'Queijo'),
('ing_013', 'prod_lanche_001', 'Alface'),
('ing_014', 'prod_lanche_001', 'Tomate'),
('ing_015', 'prod_lanche_001', 'Molho especial'),
('ing_016', 'prod_lanche_002', 'Pão brioche'),
('ing_017', 'prod_lanche_002', 'Hambúrguer 180g'),
('ing_018', 'prod_lanche_002', 'Bacon'),
('ing_019', 'prod_lanche_002', 'Queijo'),
('ing_020', 'prod_lanche_002', 'Alface'),
('ing_021', 'prod_lanche_002', 'Tomate'),
('ing_022', 'prod_lanche_002', 'Molho especial');

-- Inserir dados de exemplo para demonstração
INSERT IGNORE INTO users (id, name, email, password, role) VALUES
('user_001', 'João Silva', 'joao@email.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('user_002', 'Maria Santos', 'maria@email.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('user_003', 'Pedro Costa', 'pedro@email.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

-- Inserir endereços
INSERT IGNORE INTO addresses (id, user_id, street, number, neighborhood, city, state, zip_code, is_default) VALUES
('addr_001', 'user_001', 'Rua das Flores', '123', 'Centro', 'São Paulo', 'SP', '01234-567', TRUE),
('addr_002', 'user_002', 'Av. Paulista', '456', 'Bela Vista', 'São Paulo', 'SP', '01310-100', TRUE),
('addr_003', 'user_003', 'Rua Augusta', '789', 'Consolação', 'São Paulo', 'SP', '01305-000', TRUE);

-- Inserir pedidos de exemplo
INSERT IGNORE INTO orders (id, user_id, address_id, status, payment_method, subtotal, delivery_fee, total, created_at) VALUES
('order_001', 'user_001', 'addr_001', 'delivered', 'pix', 45.90, 5.00, 50.90, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('order_002', 'user_001', 'addr_001', 'preparing', 'credit_card', 67.80, 5.00, 72.80, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('order_003', 'user_002', 'addr_002', 'confirmed', 'cash', 38.90, 5.00, 43.90, DATE_SUB(NOW(), INTERVAL 3 HOUR)),
('order_004', 'user_003', 'addr_003', 'out_for_delivery', 'pix', 89.70, 5.00, 94.70, DATE_SUB(NOW(), INTERVAL 1 HOUR)),
('order_005', 'user_002', 'addr_002', 'pending', 'credit_card', 56.80, 5.00, 61.80, DATE_SUB(NOW(), INTERVAL 30 MINUTE));

-- Inserir itens dos pedidos
INSERT IGNORE INTO order_items (id, order_id, product_id, quantity, unit_price, notes) VALUES
('item_001', 'order_001', 'prod_pizza_001', 1, 40.90, 'Sem cebola'),
('item_002', 'order_001', 'prod_bebida_001', 1, 6.90, NULL),
('item_003', 'order_002', 'prod_pizza_002', 1, 48.90, NULL),
('item_004', 'order_002', 'prod_lanche_001', 1, 28.90, 'Bem passado'),
('item_005', 'order_003', 'prod_pizza_003', 1, 39.90, NULL),
('item_006', 'order_004', 'prod_pizza_001', 2, 40.90, NULL),
('item_007', 'order_004', 'prod_bebida_002', 1, 8.90, NULL),
('item_008', 'order_005', 'prod_lanche_002', 1, 32.90, NULL),
('item_009', 'order_005', 'prod_bebida_001', 2, 6.90, NULL);

-- =====================================================
-- VERIFICAÇÃO FINAL
-- =====================================================

-- Verificar se tudo foi criado corretamente
SELECT 'RESUMO DA INSTALAÇÃO' as info, '' as count
UNION ALL
SELECT '========================', ''
UNION ALL
SELECT 'Categorias criadas:', COUNT(*) FROM categories
UNION ALL
SELECT 'Produtos criados:', COUNT(*) FROM products
UNION ALL
SELECT 'Opções de produtos:', COUNT(*) FROM product_options
UNION ALL
SELECT 'Ingredientes:', COUNT(*) FROM product_ingredients
UNION ALL
SELECT 'Usuários criados:', COUNT(*) FROM users
UNION ALL
SELECT 'Endereços:', COUNT(*) FROM addresses
UNION ALL
SELECT 'Pedidos de exemplo:', COUNT(*) FROM orders
UNION ALL
SELECT 'Itens de pedidos:', COUNT(*) FROM order_items
UNION ALL
SELECT '========================', ''
UNION ALL
SELECT 'STATUS: INSTALAÇÃO CONCLUÍDA!', '';

-- Mostrar credenciais de acesso
SELECT 'CREDENCIAIS DE ACESSO' as info, '' as value
UNION ALL
SELECT '========================', ''
UNION ALL
SELECT 'Email Admin:', 'admin@laricas.com'
UNION ALL
SELECT 'Senha Admin:', 'admin123'
UNION ALL
SELECT 'URL Admin:', 'http://localhost:5173/admin'
UNION ALL
SELECT '========================', '';