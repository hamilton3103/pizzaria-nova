/*
  # Initial Schema Setup
  
  1. Tables
    - Users table with authentication
    - Addresses for delivery locations
    - Categories for product organization
    - Products with pricing and metadata
    - Product options and ingredients
    - Orders and order items
    
  2. Security
    - RLS enabled on all tables
    - Appropriate policies for data access
    
  3. Default Data
    - Basic product categories
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$ BEGIN
  -- Create tables if they don't exist
  
  -- Users table
  CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name varchar(100) NOT NULL,
    email varchar(100) NOT NULL UNIQUE,
    password varchar(255) NOT NULL,
    phone varchar(20),
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
  );

  -- Addresses table
  CREATE TABLE IF NOT EXISTS addresses (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    street varchar(255) NOT NULL,
    number varchar(20) NOT NULL,
    complement varchar(100),
    neighborhood varchar(100) NOT NULL,
    city varchar(100) NOT NULL,
    state varchar(2) NOT NULL,
    zip_code varchar(10) NOT NULL,
    is_default boolean DEFAULT false
  );

  -- Categories table
  CREATE TABLE IF NOT EXISTS categories (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name varchar(50) NOT NULL,
    slug varchar(50) NOT NULL UNIQUE
  );

  -- Products table
  CREATE TABLE IF NOT EXISTS products (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name varchar(100) NOT NULL,
    description text,
    price decimal(10,2) NOT NULL,
    promo_price decimal(10,2),
    image varchar(255),
    category_id uuid NOT NULL REFERENCES categories(id),
    is_active boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    is_popular boolean DEFAULT false,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
  );

  -- Product options table
  CREATE TABLE IF NOT EXISTS product_options (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    name varchar(100) NOT NULL,
    price decimal(10,2) NOT NULL DEFAULT 0
  );

  -- Product ingredients table
  CREATE TABLE IF NOT EXISTS product_ingredients (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    name varchar(100) NOT NULL
  );

  -- Orders table
  CREATE TABLE IF NOT EXISTS orders (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid NOT NULL REFERENCES users(id),
    address_id uuid NOT NULL REFERENCES addresses(id),
    status varchar(20) NOT NULL DEFAULT 'pending'
      CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
    payment_method varchar(20) NOT NULL
      CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
    subtotal decimal(10,2) NOT NULL,
    delivery_fee decimal(10,2) NOT NULL,
    total decimal(10,2) NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP
  );

  -- Order items table
  CREATE TABLE IF NOT EXISTS order_items (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id uuid NOT NULL REFERENCES products(id),
    quantity integer NOT NULL,
    unit_price decimal(10,2) NOT NULL,
    notes text
  );

  -- Order item options table
  CREATE TABLE IF NOT EXISTS order_item_options (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_item_id uuid NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
    product_option_id uuid NOT NULL REFERENCES product_options(id),
    price decimal(10,2) NOT NULL
  );

EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;

-- Enable RLS and create policies
DO $$ BEGIN
  -- Users policies
  ALTER TABLE users ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Users can read own data') THEN
    CREATE POLICY "Users can read own data"
      ON users
      FOR SELECT
      TO public
      USING (auth.uid() = id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Users can update own data') THEN
    CREATE POLICY "Users can update own data"
      ON users
      FOR UPDATE
      TO public
      USING (auth.uid() = id)
      WITH CHECK (auth.uid() = id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Users can delete own data') THEN
    CREATE POLICY "Users can delete own data"
      ON users
      FOR DELETE
      TO public
      USING (auth.uid() = id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'users' AND policyname = 'Enable insert for registration') THEN
    CREATE POLICY "Enable insert for registration"
      ON users
      FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;

  -- Addresses policies
  ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'addresses' AND policyname = 'Users can manage own addresses') THEN
    CREATE POLICY "Users can manage own addresses"
      ON addresses
      FOR ALL
      TO authenticated
      USING (auth.uid() = user_id)
      WITH CHECK (auth.uid() = user_id);
  END IF;

  -- Categories policies
  ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'categories' AND policyname = 'Anyone can read categories') THEN
    CREATE POLICY "Anyone can read categories"
      ON categories
      FOR SELECT
      TO anon, authenticated
      USING (true);
  END IF;

  -- Products policies
  ALTER TABLE products ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'products' AND policyname = 'Anyone can read products') THEN
    CREATE POLICY "Anyone can read products"
      ON products
      FOR SELECT
      TO anon, authenticated
      USING (true);
  END IF;

  -- Product options policies
  ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'product_options' AND policyname = 'Anyone can read product options') THEN
    CREATE POLICY "Anyone can read product options"
      ON product_options
      FOR SELECT
      TO anon, authenticated
      USING (true);
  END IF;

  -- Product ingredients policies
  ALTER TABLE product_ingredients ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'product_ingredients' AND policyname = 'Anyone can read product ingredients') THEN
    CREATE POLICY "Anyone can read product ingredients"
      ON product_ingredients
      FOR SELECT
      TO anon, authenticated
      USING (true);
  END IF;

  -- Orders policies
  ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'orders' AND policyname = 'Users can read their own orders') THEN
    CREATE POLICY "Users can read their own orders"
      ON orders
      FOR SELECT
      TO authenticated
      USING (auth.uid() = user_id);
  END IF;

  -- Order items policies
  ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'order_items' AND policyname = 'Users can read their own order items') THEN
    CREATE POLICY "Users can read their own order items"
      ON order_items
      FOR SELECT
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_items.order_id
        AND orders.user_id = auth.uid()
      ));
  END IF;

  -- Order item options policies
  ALTER TABLE order_item_options ENABLE ROW LEVEL SECURITY;
  
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'order_item_options' AND policyname = 'Users can read their own order item options') THEN
    CREATE POLICY "Users can read their own order item options"
      ON order_item_options
      FOR SELECT
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM order_items
        JOIN orders ON orders.id = order_items.order_id
        WHERE order_items.id = order_item_options.order_item_id
        AND orders.user_id = auth.uid()
      ));
  END IF;

EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

-- Insert default categories if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'pizza') THEN
    INSERT INTO categories (name, slug) VALUES
      ('Pizza', 'pizza'),
      ('Lanche', 'lanche'),
      ('Bebida', 'bebida'),
      ('Promoção', 'promocao'),
      ('Sobremesa', 'sobremesa');
  END IF;
END $$;