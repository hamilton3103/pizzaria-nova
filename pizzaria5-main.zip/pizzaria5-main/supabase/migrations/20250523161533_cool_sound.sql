/*
  # Fix Users Table RLS Policies

  1. Changes
    - Drop existing RLS policies on users table
    - Add new RLS policies for:
      - Allowing authenticated users to read their own data
      - Allowing new user registration (insert)
      - Allowing users to update their own data
      - Allowing users to delete their own data
  
  2. Security
    - Maintains data privacy by ensuring users can only access their own data
    - Enables new user registration
    - Prevents unauthorized modifications
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read their own data" ON users;

-- Create comprehensive RLS policies
CREATE POLICY "Enable insert for registration" ON users
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can read own data" ON users
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can delete own data" ON users
  FOR DELETE
  USING (auth.uid() = id);