/*
  # Complete database schema setup for pizzaria e-commerce

  1. New Tables
    - `users` - User accounts with authentication data
    - `categories` - Product categories (pizza, lanche, bebida, etc.)
    - `products` - Main products catalog
    - `product_options` - Product variations (sizes, flavors, etc.)
    - `product_ingredients` - Product ingredients list
    - `addresses` - User delivery addresses
    - `orders` - Customer orders
    - `order_items` - Individual items in orders
    - `order_item_options` - Selected options for order items

  2. Security
    - Enable RLS on all tables
    - Add policies for proper access control
    - Users can only access their own data
    - Public read access for products and categories

  3. Performance
    - Add indexes for frequently queried columns
    - Optimize for product searches and order lookups

  4. Data
    - Insert default categories
    - Set up proper constraints and defaults
*/

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(100) NOT NULL,
  email varchar(100) UNIQUE NOT NULL,
  password varchar(255) NOT NULL,
  phone varchar(20),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(50) NOT NULL,
  slug varchar(50) UNIQUE NOT NULL
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(100) NOT NULL,
  description text,
  price numeric(10,2) NOT NULL,
  promo_price numeric(10,2),
  image varchar(255),
  category_id uuid NOT NULL REFERENCES categories(id),
  is_active boolean DEFAULT true,
  is_featured boolean DEFAULT false,
  is_popular boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Product options table
CREATE TABLE IF NOT EXISTS product_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL,
  price numeric(10,2) DEFAULT 0
);

ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;

-- Product ingredients table
CREATE TABLE IF NOT EXISTS product_ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL
);

ALTER TABLE product_ingredients ENABLE ROW LEVEL SECURITY;

-- Addresses table
CREATE TABLE IF NOT EXISTS addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  street varchar(255) NOT NULL,
  number varchar(20) NOT NULL,
  complement varchar(100),
  neighborhood varchar(100) NOT NULL,
  city varchar(100) NOT NULL,
  state varchar(2) NOT NULL,
  zip_code varchar(10) NOT NULL,
  is_default boolean DEFAULT false
);

ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  address_id uuid NOT NULL REFERENCES addresses(id),
  status varchar(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
  payment_method varchar(20) NOT NULL CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
  subtotal numeric(10,2) NOT NULL,
  delivery_fee numeric(10,2) NOT NULL,
  total numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  notes text
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

-- Order item options table
CREATE TABLE IF NOT EXISTS order_item_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id uuid NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  product_option_id uuid NOT NULL REFERENCES product_options(id),
  price numeric(10,2) NOT NULL
);

ALTER TABLE order_item_options ENABLE ROW LEVEL SECURITY;

-- RLS Policies (with conflict handling)

-- Users policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Enable insert for registration'
  ) THEN
    CREATE POLICY "Enable insert for registration" ON users FOR INSERT WITH CHECK (true);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can read own data'
  ) THEN
    CREATE POLICY "Users can read own data" ON users FOR SELECT USING (id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can update own data'
  ) THEN
    CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can delete own data'
  ) THEN
    CREATE POLICY "Users can delete own data" ON users FOR DELETE USING (id = auth.uid());
  END IF;
END $$;

-- Categories policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'categories' AND policyname = 'Anyone can read categories'
  ) THEN
    CREATE POLICY "Anyone can read categories" ON categories FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Products policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'products' AND policyname = 'Anyone can read products'
  ) THEN
    CREATE POLICY "Anyone can read products" ON products FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Product options policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'product_options' AND policyname = 'Anyone can read product options'
  ) THEN
    CREATE POLICY "Anyone can read product options" ON product_options FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Product ingredients policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'product_ingredients' AND policyname = 'Anyone can read product ingredients'
  ) THEN
    CREATE POLICY "Anyone can read product ingredients" ON product_ingredients FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Addresses policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addresses' AND policyname = 'Users can manage own addresses'
  ) THEN
    CREATE POLICY "Users can manage own addresses" ON addresses FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
  END IF;
END $$;

-- Additional address policy for reading
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addresses' AND policyname = 'Users can read their own addresses'
  ) THEN
    CREATE POLICY "Users can read their own addresses" ON addresses FOR SELECT TO authenticated USING (user_id = auth.uid());
  END IF;
END $$;

-- Orders policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'orders' AND policyname = 'Users can read their own orders'
  ) THEN
    CREATE POLICY "Users can read their own orders" ON orders FOR SELECT TO authenticated USING (user_id = auth.uid());
  END IF;
END $$;

-- Order items policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_items' AND policyname = 'Users can read their own order items'
  ) THEN
    CREATE POLICY "Users can read their own order items" ON order_items 
    FOR SELECT TO authenticated 
    USING (EXISTS (
      SELECT 1 FROM orders 
      WHERE orders.id = order_items.order_id 
      AND orders.user_id = auth.uid()
    ));
  END IF;
END $$;

-- Order item options policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_item_options' AND policyname = 'Users can read their own order item options'
  ) THEN
    CREATE POLICY "Users can read their own order item options" ON order_item_options 
    FOR SELECT TO authenticated 
    USING (EXISTS (
      SELECT 1 FROM order_items 
      JOIN orders ON orders.id = order_items.order_id 
      WHERE order_items.id = order_item_options.order_item_id 
      AND orders.user_id = auth.uid()
    ));
  END IF;
END $$;

-- Insert default categories (with conflict handling)
INSERT INTO categories (name, slug) VALUES
('Pizza', 'pizza'),
('Lanche', 'lanche'),
('Bebida', 'bebida'),
('Promoção', 'promocao'),
('Sobremesa', 'sobremesa')
ON CONFLICT (slug) DO NOTHING;

-- Create indexes for better performance (with conflict handling)
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_products_popular ON products(is_popular);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON addresses(user_id);