/*
  # Complete database schema for Laricas Pizzaria

  1. New Tables
    - `users` - User accounts with authentication data
    - `categories` - Product categories (pizza, lanche, bebida, etc.)
    - `products` - Menu items with pricing and details
    - `product_options` - Size/variant options for products
    - `product_ingredients` - Ingredients list for products
    - `addresses` - User delivery addresses
    - `orders` - Customer orders with status tracking
    - `order_items` - Individual items within orders
    - `order_item_options` - Selected options for order items

  2. Security
    - Enable RLS on all tables
    - Public read access for products and categories
    - User-specific access for personal data (addresses, orders)
    - Secure policies for order management

  3. Data
    - Default categories inserted
    - Performance indexes created
*/

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(100) NOT NULL,
  email varchar(100) UNIQUE NOT NULL,
  password varchar(255) NOT NULL,
  phone varchar(20),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'users' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE users ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(50) NOT NULL,
  slug varchar(50) UNIQUE NOT NULL
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'categories' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(100) NOT NULL,
  description text,
  price numeric(10,2) NOT NULL,
  promo_price numeric(10,2),
  image varchar(255),
  category_id uuid NOT NULL REFERENCES categories(id),
  is_active boolean DEFAULT true,
  is_featured boolean DEFAULT false,
  is_popular boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'products' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE products ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Product options table
CREATE TABLE IF NOT EXISTS product_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL,
  price numeric(10,2) DEFAULT 0
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'product_options' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE product_options ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Product ingredients table
CREATE TABLE IF NOT EXISTS product_ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'product_ingredients' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE product_ingredients ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Addresses table
CREATE TABLE IF NOT EXISTS addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  street varchar(255) NOT NULL,
  number varchar(20) NOT NULL,
  complement varchar(100),
  neighborhood varchar(100) NOT NULL,
  city varchar(100) NOT NULL,
  state varchar(2) NOT NULL,
  zip_code varchar(10) NOT NULL,
  is_default boolean DEFAULT false
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'addresses' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  address_id uuid NOT NULL REFERENCES addresses(id),
  status varchar(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled')),
  payment_method varchar(20) NOT NULL CHECK (payment_method IN ('pix', 'credit_card', 'cash')),
  subtotal numeric(10,2) NOT NULL,
  delivery_fee numeric(10,2) NOT NULL,
  total numeric(10,2) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'orders' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  notes text
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'order_items' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Order item options table
CREATE TABLE IF NOT EXISTS order_item_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id uuid NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  product_option_id uuid NOT NULL REFERENCES product_options(id),
  price numeric(10,2) NOT NULL
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'order_item_options' AND n.nspname = 'public' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE order_item_options ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- RLS Policies (with existence checks)

-- Users policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Enable insert for registration'
  ) THEN
    CREATE POLICY "Enable insert for registration" ON users FOR INSERT WITH CHECK (true);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can read own data'
  ) THEN
    CREATE POLICY "Users can read own data" ON users FOR SELECT USING (id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can update own data'
  ) THEN
    CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Users can delete own data'
  ) THEN
    CREATE POLICY "Users can delete own data" ON users FOR DELETE USING (id = auth.uid());
  END IF;
END $$;

-- Categories policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'categories' AND policyname = 'Anyone can read categories'
  ) THEN
    CREATE POLICY "Anyone can read categories" ON categories FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Products policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'products' AND policyname = 'Anyone can read products'
  ) THEN
    CREATE POLICY "Anyone can read products" ON products FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Product options policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'product_options' AND policyname = 'Anyone can read product options'
  ) THEN
    CREATE POLICY "Anyone can read product options" ON product_options FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Product ingredients policies (public read)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'product_ingredients' AND policyname = 'Anyone can read product ingredients'
  ) THEN
    CREATE POLICY "Anyone can read product ingredients" ON product_ingredients FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

-- Addresses policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addresses' AND policyname = 'Users can manage own addresses'
  ) THEN
    CREATE POLICY "Users can manage own addresses" ON addresses FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
  END IF;
END $$;

-- Additional addresses policy for reading
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addresses' AND policyname = 'Users can read their own addresses'
  ) THEN
    CREATE POLICY "Users can read their own addresses" ON addresses FOR SELECT TO authenticated USING (user_id = auth.uid());
  END IF;
END $$;

-- Orders policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'orders' AND policyname = 'Users can read their own orders'
  ) THEN
    CREATE POLICY "Users can read their own orders" ON orders FOR SELECT TO authenticated USING (user_id = auth.uid());
  END IF;
END $$;

-- Order items policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_items' AND policyname = 'Users can read their own order items'
  ) THEN
    CREATE POLICY "Users can read their own order items" ON order_items 
    FOR SELECT TO authenticated 
    USING (EXISTS (
      SELECT 1 FROM orders 
      WHERE orders.id = order_items.order_id 
      AND orders.user_id = auth.uid()
    ));
  END IF;
END $$;

-- Order item options policies
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_item_options' AND policyname = 'Users can read their own order item options'
  ) THEN
    CREATE POLICY "Users can read their own order item options" ON order_item_options 
    FOR SELECT TO authenticated 
    USING (EXISTS (
      SELECT 1 FROM order_items 
      JOIN orders ON orders.id = order_items.order_id 
      WHERE order_items.id = order_item_options.order_item_id 
      AND orders.user_id = auth.uid()
    ));
  END IF;
END $$;

-- Insert default categories
INSERT INTO categories (name, slug) VALUES
('Pizza', 'pizza'),
('Lanche', 'lanche'),
('Bebida', 'bebida'),
('Promoção', 'promocao'),
('Sobremesa', 'sobremesa')
ON CONFLICT (slug) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_products_popular ON products(is_popular);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_addresses_user ON addresses(user_id);