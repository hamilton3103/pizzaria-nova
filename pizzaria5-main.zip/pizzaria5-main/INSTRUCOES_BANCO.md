# 📋 INSTRUÇÕES PARA CONFIGURAR O BANCO DE DADOS

## 🌐 PARA HOSPEDAGEM (Produção)

### 1. Importar no phpMyAdmin
1. Acesse o phpMyAdmin da sua hospedagem
2. Clique em "Importar"
3. Selecione o arquivo `database_export.sql`
4. Clique em "Executar"

### 2. Configurar Aplicação
1. Renomeie `.env.production` para `.env`
2. Substitua `seudominio.com` pelo seu domínio real
3. Verifique se as credenciais do banco estão corretas

### 3. Credenciais de Acesso
- **Email Admin**: admin@laricas.com
- **Senha Admin**: admin123
- **URL Admin**: https://seudominio.com/admin

---

## 💻 PARA LOCALHOST (Desenvolvimento)

### 1. Instalar MySQL Local
- **Windows**: XAMPP ou WAMP
- **Mac**: MAMP ou Homebrew
- **Linux**: `sudo apt install mysql-server`

### 2. Importar Banco
1. Abra phpMyAdmin local (http://localhost/phpmyadmin)
2. Crie um banco chamado `laricasp_bdados`
3. Importe o arquivo `database_export.sql`

### 3. Configurar Aplicação
1. Renomeie `.env.localhost` para `.env`
2. Ajuste as credenciais do MySQL local:
   - **Usuário**: geralmente `root`
   - **Senha**: deixe vazio ou sua senha do MySQL
   - **Host**: `localhost`

### 4. Iniciar Aplicação
```bash
npm install
npm run dev
```

### 5. Acessar Sistema
- **Site**: http://localhost:5173
- **Admin**: http://localhost:5173/admin
- **Email**: admin@laricas.com
- **Senha**: admin123

---

## 🔧 CONFIGURAÇÕES IMPORTANTES

### Estrutura do Banco
- **Banco**: `laricasp_bdados`
- **Tabelas**: 9 tabelas principais
- **Dados**: Categorias, produtos e usuários de exemplo
- **Charset**: utf8mb4_unicode_ci

### Credenciais Padrão
- **Admin Email**: admin@laricas.com
- **Admin Senha**: admin123
- **Usuários Teste**: joao@email.com, maria@email.com (senha: admin123)

### Funcionalidades Incluídas
- ✅ Sistema de autenticação JWT
- ✅ Painel administrativo completo
- ✅ Gestão de produtos e categorias
- ✅ Sistema de pedidos
- ✅ Relatórios e dashboard
- ✅ Upload de imagens
- ✅ API REST completa

---

## 🚨 TROUBLESHOOTING

### Erro de Conexão
1. Verifique se o MySQL está rodando
2. Confirme as credenciais no arquivo `.env`
3. Teste a conexão no phpMyAdmin

### Erro de Permissões
1. Verifique se o usuário tem permissões no banco
2. Execute: `GRANT ALL PRIVILEGES ON laricasp_bdados.* TO 'usuario'@'localhost';`

### Erro de Importação
1. Verifique se o arquivo SQL está completo
2. Importe tabela por tabela se necessário
3. Verifique logs de erro do MySQL

---

## 📞 SUPORTE

Se encontrar problemas:
1. Verifique os logs do servidor
2. Confirme as configurações do `.env`
3. Teste a conexão com o banco separadamente