/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#d32f2f',
          light: '#ffcdd2',
          dark: '#b71c1c',
        },
        secondary: {
          DEFAULT: '#ffc107',
          light: '#ffecb3',
          dark: '#ffa000',
        },
        accent: {
          DEFAULT: '#4caf50',
          light: '#c8e6c9',
          dark: '#2e7d32',
        },
        success: {
          DEFAULT: '#4caf50',
          light: '#c8e6c9',
          dark: '#2e7d32',
        },
        warning: {
          DEFAULT: '#ff9800',
          light: '#ffe0b2',
          dark: '#ef6c00',
        },
        error: {
          DEFAULT: '#f44336',
          light: '#ffcdd2',
          dark: '#c62828',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};