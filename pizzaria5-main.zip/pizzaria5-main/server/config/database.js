import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const dbConfig = {
  host: process.env.DB_HOST || '192.185.176.242',
  user: process.env.DB_USER || 'laricasp_bdados',
  password: process.env.DB_PASSWORD || 'Ha31038866##',
  database: process.env.DB_NAME || 'laricasp_bdados',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 30000,
  timeout: 30000,
  reconnect: true,
  charset: 'utf8mb4',
  connectTimeout: 20000,
  ssl: false
};

console.log('🔧 Database config:', {
  host: dbConfig.host,
  user: dbConfig.user,
  database: dbConfig.database,
  port: dbConfig.port,
  server: 'srv96'
});

// Create connection pool with error handling
let pool;
let isConnected = false;

const createPool = () => {
  try {
    pool = mysql.createPool(dbConfig);
    
    // Handle pool errors
    pool.on('connection', (connection) => {
      console.log('✅ New database connection established to srv96');
      isConnected = true;
    });
    
    pool.on('error', (err) => {
      console.error('❌ Database pool error:', err.message);
      isConnected = false;
      
      if (err.code === 'PROTOCOL_CONNECTION_LOST' || err.code === 'ETIMEDOUT') {
        console.log('🔄 Attempting to reconnect to database...');
        setTimeout(createPool, 5000);
      }
    });
    
    return pool;
  } catch (error) {
    console.error('❌ Failed to create database pool:', error.message);
    isConnected = false;
    return null;
  }
};

// Initialize pool
pool = createPool();

// Test database connection with retry logic
export const testConnection = async (retries = 3) => {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      console.log(`🔄 Database connection attempt ${attempt}/${retries} to srv96...`);
      
      if (!pool) {
        console.log('🔄 Recreating database pool...');
        pool = createPool();
        if (!pool) {
          throw new Error('Failed to create database pool');
        }
      }
      
      const connection = await pool.getConnection();
      console.log('✅ Database connected successfully to srv96');
      
      // Test admin user exists
      const [adminCheck] = await connection.execute(
        'SELECT id, name, email, role FROM users WHERE email = ? AND role = ?',
        ['admin@laricas.com', 'admin']
      );
      
      if (adminCheck.length > 0) {
        console.log('✅ Admin user found:', adminCheck[0]);
      } else {
        console.log('⚠️ Admin user not found, creating...');
        
        // Create admin user if not exists
        await connection.execute(`
          INSERT IGNORE INTO users (id, name, email, password, role) VALUES
          ('admin_001', 'Administrador', 'admin@laricas.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
        `);
        
        console.log('✅ Admin user created');
      }
      
      connection.release();
      isConnected = true;
      return true;
    } catch (error) {
      console.error(`❌ Database connection attempt ${attempt} failed:`, error.message);
      
      if (attempt === retries) {
        console.error('❌ All database connection attempts failed');
        console.error('💡 Troubleshooting suggestions:');
        console.error('   - Verify server srv96 is accessible at 192.185.176.242:3306');
        console.error('   - Check if user laricasp_bdados has access to database laricasp_bdados');
        console.error('   - Verify firewall allows connections on port 3306');
        console.error('   - Check if MySQL service is running on srv96');
        console.error('   - Verify credentials: user=laricasp_bdados, db=laricasp_bdados');
        isConnected = false;
        return false;
      }
      
      // Wait before retry
      console.log(`⏳ Waiting 3 seconds before retry...`);
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }
  
  return false;
};

// Execute query with error handling and retry logic
export const executeQuery = async (query, params = []) => {
  if (!isConnected) {
    console.log('⚠️ Database not connected, attempting to reconnect...');
    const connected = await testConnection(2);
    if (!connected) {
      throw new Error('Database connection unavailable');
    }
  }
  
  try {
    const [results] = await pool.execute(query, params);
    return results;
  } catch (error) {
    console.error('Database query error:', error.message);
    console.error('Query:', query);
    console.error('Params:', params);
    
    // If connection error, try to reconnect
    if (error.code === 'PROTOCOL_CONNECTION_LOST' || error.code === 'ETIMEDOUT') {
      console.log('🔄 Connection lost, attempting to reconnect...');
      isConnected = false;
      const connected = await testConnection(2);
      if (connected) {
        // Retry the query once
        const [results] = await pool.execute(query, params);
        return results;
      }
    }
    
    throw error;
  }
};

// Get single record
export const getOne = async (query, params = []) => {
  try {
    const results = await executeQuery(query, params);
    return results[0] || null;
  } catch (error) {
    console.error('Database query error:', error.message);
    throw error;
  }
};

// Get multiple records
export const getMany = async (query, params = []) => {
  try {
    const results = await executeQuery(query, params);
    return results;
  } catch (error) {
    console.error('Database query error:', error.message);
    throw error;
  }
};

// Check connection status
export const isDbConnected = () => isConnected;

// Graceful shutdown
export const closeConnection = async () => {
  if (pool) {
    try {
      await pool.end();
      console.log('✅ Database connection pool closed');
    } catch (error) {
      console.error('❌ Error closing database pool:', error.message);
    }
  }
};

// Initialize database connection test with delay to allow server startup
setTimeout(() => {
  testConnection();
}, 2000);

export default pool;