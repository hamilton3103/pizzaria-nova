import express from 'express';
import Joi from 'joi';
import { executeQuery, getOne, getMany } from '../config/database.js';

const router = express.Router();

// Validation schemas
const updateStatusSchema = Joi.object({
  status: Joi.string().valid('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'canceled').required()
});

// GET /api/orders
router.get('/', async (req, res, next) => {
  try {
    const { status, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT o.*, 
             u.name as customer_name, u.email as customer_email,
             a.street, a.number, a.neighborhood, a.city, a.state
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      LEFT JOIN addresses a ON o.address_id = a.id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      query += ' AND o.status = ?';
      params.push(status);
    }

    query += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const orders = await getMany(query, params);

    // Get order items for each order
    for (let order of orders) {
      const items = await getMany(`
        SELECT oi.*, p.name as product_name, p.image as product_image
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
      `, [order.id]);
      
      order.items = items;
    }

    res.json({
      success: true,
      data: orders
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/orders/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const order = await getOne(`
      SELECT o.*, 
             u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
             a.street, a.number, a.complement, a.neighborhood, a.city, a.state, a.zip_code
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      LEFT JOIN addresses a ON o.address_id = a.id
      WHERE o.id = ?
    `, [id]);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    // Get order items
    const items = await getMany(`
      SELECT oi.*, p.name as product_name, p.image as product_image, p.description as product_description
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `, [id]);

    order.items = items;

    res.json({
      success: true,
      data: order
    });

  } catch (error) {
    next(error);
  }
});

// PUT /api/orders/:id/status
router.put('/:id/status', async (req, res, next) => {
  try {
    const { id } = req.params;

    // Validate input
    const { error, value } = updateStatusSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const { status } = value;

    // Check if order exists
    const existingOrder = await getOne('SELECT * FROM orders WHERE id = ?', [id]);
    if (!existingOrder) {
      return res.status(404).json({
        success: false,
        message: 'Pedido não encontrado'
      });
    }

    // Update order status
    await executeQuery(
      'UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [status, id]
    );

    // Get updated order
    const updatedOrder = await getOne(`
      SELECT o.*, 
             u.name as customer_name, u.email as customer_email
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      WHERE o.id = ?
    `, [id]);

    res.json({
      success: true,
      message: 'Status do pedido atualizado com sucesso',
      data: updatedOrder
    });

  } catch (error) {
    next(error);
  }
});

export default router;