import express from 'express';
import { getOne, getMany } from '../config/database.js';

const router = express.Router();

// GET /api/clients
router.get('/', async (req, res, next) => {
  try {
    const { search, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT u.id, u.name, u.email, u.phone, u.created_at,
             COUNT(DISTINCT o.id) as total_orders,
             COALESCE(SUM(o.total), 0) as total_spent,
             MAX(o.created_at) as last_order_date
      FROM users u
      LEFT JOIN orders o ON u.id = o.user_id
      WHERE u.role = 'user'
    `;
    const params = [];

    if (search) {
      query += ' AND (u.name LIKE ? OR u.email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' GROUP BY u.id ORDER BY u.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const clients = await getMany(query, params);

    res.json({
      success: true,
      data: clients
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/clients/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    // Get client details
    const client = await getOne(`
      SELECT u.id, u.name, u.email, u.phone, u.created_at,
             COUNT(DISTINCT o.id) as total_orders,
             COALESCE(SUM(o.total), 0) as total_spent,
             MAX(o.created_at) as last_order_date
      FROM users u
      LEFT JOIN orders o ON u.id = o.user_id
      WHERE u.id = ? AND u.role = 'user'
      GROUP BY u.id
    `, [id]);

    if (!client) {
      return res.status(404).json({
        success: false,
        message: 'Cliente não encontrado'
      });
    }

    // Get client addresses
    const addresses = await getMany(
      'SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC',
      [id]
    );

    // Get recent orders
    const recentOrders = await getMany(`
      SELECT o.id, o.status, o.total, o.created_at,
             COUNT(oi.id) as items_count
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE o.user_id = ?
      GROUP BY o.id
      ORDER BY o.created_at DESC
      LIMIT 10
    `, [id]);

    client.addresses = addresses;
    client.recent_orders = recentOrders;

    res.json({
      success: true,
      data: client
    });

  } catch (error) {
    next(error);
  }
});

export default router;