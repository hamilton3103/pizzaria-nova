import express from 'express';
import bcrypt from 'bcryptjs';
import Joi from 'joi';
import { getOne, executeQuery } from '../config/database.js';
import { 
  generateTokens, 
  verifyRefreshToken, 
  blacklistToken,
  authenticateToken 
} from '../middleware/auth.js';

const router = express.Router();

// Validation schemas
const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(3).required(),
  rememberMe: Joi.boolean().default(false)
});

const refreshTokenSchema = Joi.object({
  refreshToken: Joi.string().required()
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    console.log('🔐 Login attempt:', { email: req.body.email, timestamp: new Date().toISOString() });

    // Validate input
    const { error, value } = loginSchema.validate(req.body);
    if (error) {
      console.log('❌ Validation error:', error.details[0].message);
      return res.status(400).json({
        success: false,
        message: error.details[0].message,
        code: 'VALIDATION_ERROR'
      });
    }

    const { email, password, rememberMe } = value;

    // Find admin user
    const user = await getOne(
      'SELECT id, name, email, password, role, created_at FROM users WHERE email = ? AND role = "admin"',
      [email]
    );

    console.log('🔍 User lookup result:', user ? 'Found' : 'Not found');

    if (!user) {
      console.log('❌ User not found or not admin');
      return res.status(401).json({
        success: false,
        message: 'Email ou senha incorretos. Por favor, verifique suas credenciais.',
        code: 'INVALID_CREDENTIALS'
      });
    }

    // Verify password
    console.log('🔑 Verifying password...');
    const isValidPassword = await bcrypt.compare(password, user.password);
    
    console.log('🔑 Password verification result:', isValidPassword);

    if (!isValidPassword) {
      console.log('❌ Invalid password');
      return res.status(401).json({
        success: false,
        message: 'Email ou senha incorretos. Por favor, verifique suas credenciais.',
        code: 'INVALID_CREDENTIALS'
      });
    }

    // Generate tokens
    const tokens = generateTokens(user.id, user.email, user.role);

    // Store refresh token in database (opcional - para maior segurança)
    await executeQuery(
      'UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [user.id]
    );

    console.log('✅ Login successful for:', user.email);

    // Return success response with tokens
    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      data: {
        ...tokens,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          createdAt: user.created_at
        }
      }
    });

  } catch (error) {
    console.error('❌ Login error:', error);
    next(error);
  }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res, next) => {
  try {
    console.log('🔄 Token refresh attempt');

    const { error, value } = refreshTokenSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message,
        code: 'VALIDATION_ERROR'
      });
    }

    const { refreshToken } = value;

    // Verify refresh token
    const decoded = verifyRefreshToken(refreshToken);
    
    // Verify user still exists and is admin
    const user = await getOne(
      'SELECT id, name, email, role FROM users WHERE id = ? AND role = "admin"',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Usuário não encontrado ou sem permissões',
        code: 'USER_NOT_FOUND'
      });
    }

    // Generate new tokens
    const newTokens = generateTokens(user.id, user.email, user.role);

    console.log('✅ Token refresh successful for:', user.email);

    res.json({
      success: true,
      message: 'Token renovado com sucesso',
      data: {
        ...newTokens,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      }
    });

  } catch (error) {
    console.error('❌ Token refresh error:', error);
    res.status(401).json({
      success: false,
      message: 'Token de renovação inválido',
      code: 'INVALID_REFRESH_TOKEN'
    });
  }
});

// POST /api/auth/logout
router.post('/logout', authenticateToken, async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
      // Adicionar token à blacklist
      blacklistToken(token);
    }

    console.log('🚪 Logout successful for:', req.user.email);

    res.json({
      success: true,
      message: 'Logout realizado com sucesso'
    });

  } catch (error) {
    console.error('❌ Logout error:', error);
    next(error);
  }
});

// POST /api/auth/verify
router.post('/verify', authenticateToken, async (req, res, next) => {
  try {
    res.json({
      success: true,
      message: 'Token válido',
      data: {
        user: {
          id: req.user.id,
          name: req.user.name,
          email: req.user.email,
          role: req.user.role
        },
        tokenInfo: {
          issuedAt: req.user.tokenIat,
          expiresAt: req.user.tokenExp
        }
      }
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/auth/me
router.get('/me', authenticateToken, async (req, res, next) => {
  try {
    const user = await getOne(
      'SELECT id, name, email, role, created_at, updated_at FROM users WHERE id = ?',
      [req.user.id]
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado',
        code: 'USER_NOT_FOUND'
      });
    }

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          createdAt: user.created_at,
          updatedAt: user.updated_at
        }
      }
    });

  } catch (error) {
    next(error);
  }
});

export default router;