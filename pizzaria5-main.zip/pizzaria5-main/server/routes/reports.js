import express from 'express';
import { getMany, getOne } from '../config/database.js';

const router = express.Router();

// GET /api/reports/sales
router.get('/sales', async (req, res, next) => {
  try {
    const { period = '30' } = req.query;
    const days = parseInt(period);

    // Total sales
    const totalSales = await getOne(`
      SELECT 
        COUNT(*) as total_orders,
        COALESCE(SUM(total), 0) as total_revenue,
        COALESCE(AVG(total), 0) as average_order_value
      FROM orders 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        AND status != 'canceled'
    `, [days]);

    // Daily sales
    const dailySales = await getMany(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as orders_count,
        SUM(total) as revenue
      FROM orders 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        AND status != 'canceled'
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `, [days]);

    // Sales by status
    const salesByStatus = await getMany(`
      SELECT 
        status,
        COUNT(*) as count,
        SUM(total) as revenue
      FROM orders 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
      GROUP BY status
      ORDER BY count DESC
    `, [days]);

    res.json({
      success: true,
      data: {
        summary: totalSales,
        daily_sales: dailySales,
        sales_by_status: salesByStatus
      }
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/reports/products-popularity
router.get('/products-popularity', async (req, res, next) => {
  try {
    const { period = '30' } = req.query;
    const days = parseInt(period);

    const popularProducts = await getMany(`
      SELECT 
        p.id,
        p.name,
        p.image,
        p.price,
        SUM(oi.quantity) as total_sold,
        COUNT(DISTINCT oi.order_id) as orders_count,
        SUM(oi.quantity * oi.unit_price) as total_revenue
      FROM products p
      INNER JOIN order_items oi ON p.id = oi.product_id
      INNER JOIN orders o ON oi.order_id = o.id
      WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        AND o.status != 'canceled'
      GROUP BY p.id, p.name, p.image, p.price
      ORDER BY total_sold DESC
      LIMIT 20
    `, [days]);

    res.json({
      success: true,
      data: popularProducts
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/reports/customers
router.get('/customers', async (req, res, next) => {
  try {
    const { period = '30' } = req.query;
    const days = parseInt(period);

    // Customer stats
    const customerStats = await getOne(`
      SELECT 
        COUNT(DISTINCT u.id) as total_customers,
        COUNT(DISTINCT CASE WHEN o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) THEN u.id END) as active_customers,
        COUNT(DISTINCT CASE WHEN u.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) THEN u.id END) as new_customers
      FROM users u
      LEFT JOIN orders o ON u.id = o.user_id
      WHERE u.role = 'user'
    `, [days, days]);

    // Top customers
    const topCustomers = await getMany(`
      SELECT 
        u.id,
        u.name,
        u.email,
        COUNT(o.id) as total_orders,
        SUM(o.total) as total_spent,
        MAX(o.created_at) as last_order_date
      FROM users u
      INNER JOIN orders o ON u.id = o.user_id
      WHERE u.role = 'user'
        AND o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        AND o.status != 'canceled'
      GROUP BY u.id, u.name, u.email
      ORDER BY total_spent DESC
      LIMIT 10
    `, [days]);

    res.json({
      success: true,
      data: {
        stats: customerStats,
        top_customers: topCustomers
      }
    });

  } catch (error) {
    next(error);
  }
});

export default router;