import express from 'express';
import Joi from 'joi';
import { executeQuery, getOne, getMany } from '../config/database.js';
import upload from '../middleware/upload.js';

const router = express.Router();

// Validation schemas
const productSchema = Joi.object({
  name: Joi.string().min(3).max(100).required(),
  description: Joi.string().min(10).max(1000).required(),
  price: Joi.number().positive().required(),
  promo_price: Joi.number().positive().allow(null),
  category_id: Joi.string().required(),
  is_active: Joi.boolean().default(true),
  is_featured: Joi.boolean().default(false),
  is_popular: Joi.boolean().default(false)
});

const updateProductSchema = Joi.object({
  name: Joi.string().min(3).max(100),
  description: Joi.string().min(10).max(1000),
  price: Joi.number().positive(),
  promo_price: Joi.number().positive().allow(null),
  category_id: Joi.string(),
  is_active: Joi.boolean(),
  is_featured: Joi.boolean(),
  is_popular: Joi.boolean()
});

// GET /api/products
router.get('/', async (req, res, next) => {
  try {
    const { category, search, featured, popular, active } = req.query;
    
    let query = `
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (category) {
      query += ' AND c.slug = ?';
      params.push(category);
    }

    if (search) {
      query += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    if (featured !== undefined) {
      query += ' AND p.is_featured = ?';
      params.push(featured === 'true');
    }

    if (popular !== undefined) {
      query += ' AND p.is_popular = ?';
      params.push(popular === 'true');
    }

    if (active !== undefined) {
      query += ' AND p.is_active = ?';
      params.push(active === 'true');
    }

    query += ' ORDER BY p.created_at DESC';

    const products = await getMany(query, params);

    res.json({
      success: true,
      data: products
    });

  } catch (error) {
    next(error);
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const product = await getOne(`
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `, [id]);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Produto não encontrado'
      });
    }

    res.json({
      success: true,
      data: product
    });

  } catch (error) {
    next(error);
  }
});

// POST /api/products
router.post('/', upload.single('image'), async (req, res, next) => {
  try {
    // Validate input
    const { error, value } = productSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const productData = value;

    // Handle image upload
    if (req.file) {
      productData.image = `/uploads/${req.file.filename}`;
    }

    // Generate ID
    const productId = `prod_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Insert product
    await executeQuery(`
      INSERT INTO products (id, name, description, price, promo_price, image, category_id, is_active, is_featured, is_popular)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      productId,
      productData.name,
      productData.description,
      productData.price,
      productData.promo_price,
      productData.image,
      productData.category_id,
      productData.is_active,
      productData.is_featured,
      productData.is_popular
    ]);

    // Get created product
    const newProduct = await getOne(`
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `, [productId]);

    res.status(201).json({
      success: true,
      message: 'Produto criado com sucesso',
      data: newProduct
    });

  } catch (error) {
    next(error);
  }
});

// PUT /api/products/:id
router.put('/:id', upload.single('image'), async (req, res, next) => {
  try {
    const { id } = req.params;

    // Check if product exists
    const existingProduct = await getOne('SELECT * FROM products WHERE id = ?', [id]);
    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: 'Produto não encontrado'
      });
    }

    // Validate input
    const { error, value } = updateProductSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const updateData = value;

    // Handle image upload
    if (req.file) {
      updateData.image = `/uploads/${req.file.filename}`;
    }

    // Build update query
    const fields = Object.keys(updateData);
    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = Object.values(updateData);

    if (fields.length > 0) {
      await executeQuery(
        `UPDATE products SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [...values, id]
      );
    }

    // Get updated product
    const updatedProduct = await getOne(`
      SELECT p.*, c.name as category_name, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `, [id]);

    res.json({
      success: true,
      message: 'Produto atualizado com sucesso',
      data: updatedProduct
    });

  } catch (error) {
    next(error);
  }
});

// DELETE /api/products/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    // Check if product exists
    const existingProduct = await getOne('SELECT * FROM products WHERE id = ?', [id]);
    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: 'Produto não encontrado'
      });
    }

    // Soft delete (set as inactive)
    await executeQuery('UPDATE products SET is_active = false WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Produto removido com sucesso'
    });

  } catch (error) {
    next(error);
  }
});

export default router;