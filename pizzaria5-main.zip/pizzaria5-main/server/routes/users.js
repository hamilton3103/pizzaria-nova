import express from 'express';
import bcrypt from 'bcryptjs';
import Joi from 'joi';
import { executeQuery, getOne, getMany } from '../config/database.js';

const router = express.Router();

// Validation schemas
const createUserSchema = Joi.object({
  name: Joi.string().min(3).max(100).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  phone: Joi.string().allow(''),
  role: Joi.string().valid('admin', 'user').default('admin')
});

const updateUserSchema = Joi.object({
  name: Joi.string().min(3).max(100),
  email: Joi.string().email(),
  password: Joi.string().min(6),
  phone: Joi.string().allow(''),
  role: Joi.string().valid('admin', 'user')
});

// GET /api/users
router.get('/', async (req, res, next) => {
  try {
    const { role, search } = req.query;
    
    let query = 'SELECT id, name, email, phone, role, created_at, updated_at FROM users WHERE 1=1';
    const params = [];

    if (role) {
      query += ' AND role = ?';
      params.push(role);
    }

    if (search) {
      query += ' AND (name LIKE ? OR email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY created_at DESC';

    const users = await getMany(query, params);

    res.json({
      success: true,
      data: users
    });

  } catch (error) {
    next(error);
  }
});

// POST /api/users
router.post('/', async (req, res, next) => {
  try {
    // Validate input
    const { error, value } = createUserSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const userData = value;

    // Check if email already exists
    const existingUser = await getOne('SELECT id FROM users WHERE email = ?', [userData.email]);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Email já está em uso'
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(userData.password, 10);

    // Generate ID
    const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Insert user
    await executeQuery(`
      INSERT INTO users (id, name, email, password, phone, role)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      userId,
      userData.name,
      userData.email,
      hashedPassword,
      userData.phone,
      userData.role
    ]);

    // Get created user (without password)
    const newUser = await getOne(
      'SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?',
      [userId]
    );

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      data: newUser
    });

  } catch (error) {
    next(error);
  }
});

// PUT /api/users/:id
router.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    // Check if user exists
    const existingUser = await getOne('SELECT * FROM users WHERE id = ?', [id]);
    if (!existingUser) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }

    // Validate input
    const { error, value } = updateUserSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const updateData = value;

    // Hash password if provided
    if (updateData.password) {
      updateData.password = await bcrypt.hash(updateData.password, 10);
    }

    // Check email uniqueness if email is being updated
    if (updateData.email && updateData.email !== existingUser.email) {
      const emailExists = await getOne('SELECT id FROM users WHERE email = ? AND id != ?', [updateData.email, id]);
      if (emailExists) {
        return res.status(400).json({
          success: false,
          message: 'Email já está em uso'
        });
      }
    }

    // Build update query
    const fields = Object.keys(updateData);
    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const values = Object.values(updateData);

    if (fields.length > 0) {
      await executeQuery(
        `UPDATE users SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [...values, id]
      );
    }

    // Get updated user (without password)
    const updatedUser = await getOne(
      'SELECT id, name, email, phone, role, created_at, updated_at FROM users WHERE id = ?',
      [id]
    );

    res.json({
      success: true,
      message: 'Usuário atualizado com sucesso',
      data: updatedUser
    });

  } catch (error) {
    next(error);
  }
});

export default router;