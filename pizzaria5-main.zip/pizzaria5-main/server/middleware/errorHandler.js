export const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);

  // Default error
  let error = {
    success: false,
    message: 'Erro interno do servidor'
  };

  // MySQL errors
  if (err.code === 'ER_DUP_ENTRY') {
    error.message = 'Registro duplicado';
    return res.status(400).json(error);
  }

  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    error.message = 'Referência inválida';
    return res.status(400).json(error);
  }

  // Validation errors
  if (err.isJoi) {
    error.message = err.details[0].message;
    return res.status(400).json(error);
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    error.message = 'Token inválido';
    return res.status(401).json(error);
  }

  if (err.name === 'TokenExpiredError') {
    error.message = 'Token expirado';
    return res.status(401).json(error);
  }

  // File upload errors
  if (err.code === 'LIMIT_FILE_SIZE') {
    error.message = 'Arquivo muito grande';
    return res.status(400).json(error);
  }

  // Custom errors
  if (err.status) {
    error.message = err.message;
    return res.status(err.status).json(error);
  }

  // Default server error
  res.status(500).json(error);
};