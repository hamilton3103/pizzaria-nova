import jwt from 'jsonwebtoken';
import { getOne } from '../config/database.js';

const JWT_SECRET = process.env.JWT_SECRET || 'laricas_admin_secret_key_2024';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'laricas_refresh_secret_key_2024';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '15m'; // Token principal expira em 15 minutos
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d'; // Refresh token expira em 7 dias

export const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token de acesso requerido',
        code: 'TOKEN_REQUIRED'
      });
    }

    // Verificar se o token está na blacklist (opcional - para logout)
    const isBlacklisted = await isTokenBlacklisted(token);
    if (isBlacklisted) {
      return res.status(401).json({
        success: false,
        message: 'Token inválido ou expirado',
        code: 'TOKEN_BLACKLISTED'
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Verificar se o usuário ainda existe e tem permissões
    const user = await getOne(
      'SELECT id, name, email, role, created_at, updated_at FROM users WHERE id = ? AND role = "admin"',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Usuário não encontrado ou sem permissões',
        code: 'USER_NOT_FOUND'
      });
    }

    // Verificar se o token não é muito antigo (segurança adicional)
    const tokenAge = Date.now() - (decoded.iat * 1000);
    const maxTokenAge = 24 * 60 * 60 * 1000; // 24 horas
    
    if (tokenAge > maxTokenAge) {
      return res.status(401).json({
        success: false,
        message: 'Token expirado, faça login novamente',
        code: 'TOKEN_TOO_OLD'
      });
    }

    // Adicionar informações do usuário à requisição
    req.user = {
      ...user,
      tokenIat: decoded.iat,
      tokenExp: decoded.exp
    };

    // Log de acesso para auditoria
    console.log(`🔐 Access granted for user: ${user.email} at ${new Date().toISOString()}`);
    
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    
    let errorResponse = {
      success: false,
      message: 'Token inválido',
      code: 'TOKEN_INVALID'
    };

    if (error.name === 'TokenExpiredError') {
      errorResponse.message = 'Token expirado';
      errorResponse.code = 'TOKEN_EXPIRED';
    } else if (error.name === 'JsonWebTokenError') {
      errorResponse.message = 'Token malformado';
      errorResponse.code = 'TOKEN_MALFORMED';
    }

    return res.status(401).json(errorResponse);
  }
};

// Middleware opcional para verificar se o token está próximo do vencimento
export const checkTokenExpiration = (req, res, next) => {
  if (req.user && req.user.tokenExp) {
    const timeUntilExpiry = (req.user.tokenExp * 1000) - Date.now();
    const fiveMinutes = 5 * 60 * 1000;
    
    if (timeUntilExpiry < fiveMinutes) {
      res.setHeader('X-Token-Warning', 'Token expiring soon');
      res.setHeader('X-Token-Expires-In', Math.floor(timeUntilExpiry / 1000));
    }
  }
  next();
};

export const generateTokens = (userId, email, role) => {
  const payload = {
    userId,
    email,
    role,
    iat: Math.floor(Date.now() / 1000)
  };

  const accessToken = jwt.sign(payload, JWT_SECRET, { 
    expiresIn: JWT_EXPIRES_IN,
    issuer: 'laricas-admin',
    audience: 'laricas-users'
  });

  const refreshToken = jwt.sign(
    { ...payload, type: 'refresh' }, 
    JWT_REFRESH_SECRET, 
    { 
      expiresIn: JWT_REFRESH_EXPIRES_IN,
      issuer: 'laricas-admin',
      audience: 'laricas-users'
    }
  );

  return {
    accessToken,
    refreshToken,
    expiresIn: JWT_EXPIRES_IN,
    tokenType: 'Bearer'
  };
};

export const verifyRefreshToken = (refreshToken) => {
  try {
    return jwt.verify(refreshToken, JWT_REFRESH_SECRET);
  } catch (error) {
    throw new Error('Invalid refresh token');
  }
};

// Função para verificar se o token está na blacklist (implementação simples em memória)
const tokenBlacklist = new Set();

export const blacklistToken = (token) => {
  tokenBlacklist.add(token);
  
  // Limpar tokens expirados da blacklist periodicamente
  setTimeout(() => {
    tokenBlacklist.delete(token);
  }, 24 * 60 * 60 * 1000); // Remove após 24 horas
};

const isTokenBlacklisted = async (token) => {
  return tokenBlacklist.has(token);
};

// Middleware para rate limiting baseado em token
export const tokenRateLimit = (maxRequests = 100, windowMs = 15 * 60 * 1000) => {
  const requests = new Map();

  return (req, res, next) => {
    if (!req.user) {
      return next();
    }

    const userId = req.user.id;
    const now = Date.now();
    const windowStart = now - windowMs;

    // Limpar requisições antigas
    if (requests.has(userId)) {
      const userRequests = requests.get(userId).filter(time => time > windowStart);
      requests.set(userId, userRequests);
    }

    const userRequests = requests.get(userId) || [];
    
    if (userRequests.length >= maxRequests) {
      return res.status(429).json({
        success: false,
        message: 'Muitas requisições. Tente novamente em alguns minutos.',
        code: 'RATE_LIMIT_EXCEEDED'
      });
    }

    userRequests.push(now);
    requests.set(userId, userRequests);
    
    next();
  };
};